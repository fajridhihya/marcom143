package com.spring.marcom143.dao;

import java.util.List;

import com.spring.marcom143.model.MenuAccessModel;

public interface MenuAccessDao {
	
	public void insert(MenuAccessModel menuAccessModel) throws Exception;
	public List<MenuAccessModel> list() throws Exception;
	public MenuAccessModel detail(Integer idMenuAccess) throws Exception;
	public void update(MenuAccessModel menuAccessModel) throws Exception;
	public void delete(MenuAccessModel menuAccessModel) throws Exception;
	
	public List<MenuAccessModel> cekMenuAccess(Integer idRole, Integer idMenu) throws Exception;
	
}
