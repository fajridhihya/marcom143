package com.spring.marcom143.service.impl;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.marcom143.dao.MenuDao;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.service.MenuService;



@Service
@Transactional
public class MenuServiceImpl implements MenuService{
	@Autowired
	private MenuDao menuDao;

	@Override
	public void insert(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		this.menuDao.insert(menuModel);
	}

	@Override
	public List<MenuModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.menuDao.list();
	}

	

	@Override
	public void update(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		this.menuDao.update(menuModel);
	}

	@Override
	public void delete(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		this.menuDao.delete(menuModel);
	}

	@Override
	public MenuModel detailByCode(String codeMenu) throws Exception {
		// TODO Auto-generated method stub
		return this.menuDao.detailByCode(codeMenu);
	}

	@Override
	public MenuModel detailById(Integer idMenu) throws Exception {
		// TODO Auto-generated method stub
		return this.menuDao.detailById(idMenu);
	}


	@Override
	public List<MenuModel> getMenuLogin(Integer idRole) throws Exception {
		// TODO Auto-generated method stub
		return this.menuDao.getMenuLogin(idRole);
	}

	
	
	
}
