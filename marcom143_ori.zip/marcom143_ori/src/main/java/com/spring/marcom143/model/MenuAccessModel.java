package com.spring.marcom143.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "MST_MENU_ACCESS")
public class MenuAccessModel {

	private Integer idMenuAccess;
	
	private Integer idRole;
	private RoleModel roleModel;
	
	private Integer idMenu;
	private MenuModel menuModel;
	
	private Integer isDelete;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	
	@Id
	@Column(name = "ID_MENU_ACCESS")
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "MST_MENU_ACCESS")
	@TableGenerator(name = "MST_MENU_ACCESS", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME", 
					pkColumnValue = "MST_MENU_ACCESS", valueColumnName = "SEQUENCE_VALUE",
					allocationSize=1, initialValue=1)
	public Integer getIdMenuAccess() {
		return idMenuAccess;
	}
	public void setIdMenuAccess(Integer idMenuAccess) {
		this.idMenuAccess = idMenuAccess;
	}

	@Column(name = "M_ID_ROLE")	
	public Integer getIdRole() {
		return idRole;
	}
	public void setIdRole(Integer idRole) {
		this.idRole = idRole;
	}	
	
	@ManyToOne
	@JoinColumn(name = "M_ID_ROLE", nullable = false, updatable = false, insertable = false )
	public RoleModel getRoleModel() {
		return roleModel;
	}
	public void setRoleModel(RoleModel roleModel) {
		this.roleModel = roleModel;
	}
	
	@Column(name = "M_ID_MENU")
	public Integer getIdMenu() {
		return idMenu;
	}
	public void setIdMenu(Integer idMenu) {
		this.idMenu = idMenu;
	}	
	
	@ManyToOne
	@JoinColumn(name = "M_ID_MENU", nullable = false, updatable = false, insertable = false )
	public MenuModel getMenuModel() {
		return menuModel;
	}
	public void setMenuModel(MenuModel menuModel) {
		this.menuModel = menuModel;
	}
	
	@Column(name = "IS_DELETE")
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name = "CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name= "UPDATE_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name = "UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
