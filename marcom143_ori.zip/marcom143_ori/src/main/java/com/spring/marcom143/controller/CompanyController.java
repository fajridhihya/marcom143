package com.spring.marcom143.controller;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.marcom143.model.CompanyModel;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.service.CompanyService;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.tools.CompanyCodeGenerator;

@Controller
public class CompanyController extends BaseController{

	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private MenuService menuService;

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	/*requestmapping value maksdnya ketika diklik url/ action dari company.html */
	/*String company(Model model) maksudnya ini adalah method company*/
	@RequestMapping(value="company")
	public String company(Model model) {
		this.accessLogin(model);
		// return company mksdnya memanggil company.jsp di folder web-inf/jsp
		return "company";		
	}
	
	//action url memanggil tambah company.jsp
	@RequestMapping(value = "company/tambah")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub
		// Skrip untuk generate Kode otomatis
		String codeCompanyGenerator = "";
		Boolean cek = false;

		while (cek == false) {

			CompanyModel companyModel = new CompanyModel();
			// kode digenerate dengan inisial namanya, semisal SUP
			// ini kode akan dihasilkan dari kelas KodeGenerator
			codeCompanyGenerator = CompanyCodeGenerator.generator("CP");

			// setelah itu dicek dlu apakah kode hasil generatenya sudah ada di database
			companyModel = this.companyService.detailByCode(codeCompanyGenerator);

			// jika benar maka looping while berhenti, dan kode terakhir generate
			// akan dijadikan kode yang ditampilkan di jspnya
			if (companyModel == null) {
				cek = true;
			}

			// kodecompanyGenerator akan dikirim ke pop up tambah company jsp
			// dimana akan mengisi otomatis nilainya
			model.addAttribute("codeCompanyGenerator", codeCompanyGenerator);

		}
			
			return "company/add";
		}
		
		//action url memanggil tambah company.jsp
		@RequestMapping(value="company/simpan")
		private String simpan(@ModelAttribute CompanyModel companyModel, HttpServletRequest request, Model model) {
			// TODO Auto-generated method stub
			/*variable proses menentukan apakah kita ingin insert data baru, update data lama, atau hapus data*/
			String proses = request.getParameter("proses");
			
			/*dibutuhkan try catch karena memanggil service*/
			try {
				
				if (proses.equals("insert")) {
					// Set create and on
					companyModel.setCreatedBy(this.getUserModel().getUsername());
					companyModel.setCreatedDate(new Date());
					
					//Set is_delete defaultnya 0 --> artinya belum terhapus
					companyModel.setIsDelete(0);
					
					this.companyService.insert(companyModel);
					
				}else if (proses.equals("update")) {
					// Set modified by and on
					CompanyModel companyModelOld = new CompanyModel();
					companyModelOld = this.companyService.detailByID(companyModel.getCompany_id());
					
					companyModel.setCreatedBy(companyModelOld.getCreatedBy());
					companyModel.setCreatedDate(companyModelOld.getCreatedDate());
					companyModel.setIsDelete(companyModelOld.getIsDelete());
					
					companyModel.setUpdatedBy(this.getUserModel().getUsername());
					companyModel.setUpdatedDate(new Date());
					
					this.companyService.update(companyModel);
					
				}else if (proses.equals("delete")) {
					//deletenya hanya update is_delete tdnya 0 jd 1
					CompanyModel companyModelOld = new CompanyModel();
					companyModelOld = this.companyService.detailByID(companyModel.getCompany_id());
					
					companyModel.setCreatedBy(companyModelOld.getCreatedBy());
					companyModel.setCreatedDate(companyModelOld.getCreatedDate());
					
					companyModel.setUpdatedBy(this.getUserModel().getUsername());
					companyModel.setUpdatedDate(new Date());
					
					companyModel.setIsDelete(1);
					
					this.companyService.update(companyModel);
					
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			model.addAttribute("result",proses);
			return "company";
		}
	
		//action untuk menampilkan looping data company dari table company
		@RequestMapping(value="company/list")
		private String list(Model model) {
			// membuat object list dari class company model
			// List nya import dari java.util
			List<CompanyModel> companys = null;

			try {
				// object items diisi data dari method get
				companys = this.companyService.list();
			} catch (Exception e) {
				//log.error(e.getMessage(), e);
			}

			// datanya kita kirim ke view = jsp,
			// kita buat variable list kemudian diisi dengan object companys
			model.addAttribute("companyList", companys);
			
			//model.addAttribute(VARIABLE DI JSP, NILAI VARIABLENYA);
			
			return "company/list";
		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="company/detail")
		private String detail(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer company_id = Integer.valueOf(request.getParameter("company_id"));
			CompanyModel companyModel = new CompanyModel();
			
			try {
				
				companyModel = this.companyService.detailByID(company_id);
						
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("companyModel",companyModel);
			return "company/detail";

		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="company/edit")
		private String edit(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer company_id = Integer.valueOf(request.getParameter("company_id"));
			CompanyModel companyModel = new CompanyModel();
			
			try {
					
				companyModel = this.companyService.detailByID(company_id);
						
			} catch (Exception e) {
				// TODO: handle exception
			}
				
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("companyModel",companyModel);
			return "company/edit";

		}
		
		//action untuk menampilkan pop up form delete
		@RequestMapping(value="company/delete")
		private String delete(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer company_id = Integer.valueOf(request.getParameter("company_id"));
			CompanyModel companyModel = new CompanyModel();
			
			try {
					
				companyModel = this.companyService.detailByID(company_id);
						
			} catch (Exception e) {
				// TODO: handle exception
			}
					
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("companyModel",companyModel);
			return "company/delete";

		}
	
}
