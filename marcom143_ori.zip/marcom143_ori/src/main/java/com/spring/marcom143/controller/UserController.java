package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.EmployeeModel;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.RoleModel;
import com.spring.marcom143.model.UserModel;
import com.spring.marcom143.service.EmployeeService;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.RoleService;
import com.spring.marcom143.service.UserService;

@Controller
public class UserController extends BaseController {
	
	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private EmployeeService employeeService;
	
	
	@Autowired 
	private MenuService menuService;
	

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login

	
	@RequestMapping(value = "user")
	public String user(Model model) {
		// this.accessLogin(model) memanggil method accessLogin
				this.accessLogin(model);
		return "user";
	}

	@RequestMapping(value = "user/tambah")
	public String tambah(Model model) {
		
		List<RoleModel> role = new ArrayList<RoleModel>();
		List<EmployeeModel> employee  = new ArrayList<EmployeeModel>();
		
		try {
			role = this.roleService.list();
			employee = this.employeeService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("roleList", role);
		model.addAttribute("employeeList", employee);
		
		return "user/add";
	}

	@RequestMapping(value = "user/simpan")
	public String simpan(@ModelAttribute UserModel userModel, HttpServletRequest request, Model model) {

		String proses = request.getParameter("proses");

		try {
			if (proses.equals("insert")) {
				// Set create and on
				userModel.setCreatedBy(this.getUserModel().getUsername());
				userModel.setCreatedDate(new Date());
				
				//Set is_delete defaultnya 0 --> artinya belum terhapus
				userModel.setIsDelete(0);
				
				this.userService.insert(userModel);
			} else if (proses.equals("update")) {
				// Set modified by and on
				UserModel userModelOld = new UserModel();
				userModelOld = this.userService.detail(userModel.getIdUser());
				
				userModel.setCreatedBy(userModelOld.getCreatedBy());
				userModel.setCreatedDate(userModelOld.getCreatedDate());
				userModel.setIsDelete(userModelOld.getIsDelete());
				
				userModel.setUpdatedBy(this.getUserModel().getUsername());
				userModel.setUpdatedDate(new Date());
				
				this.userService.update(userModel);
			} else if (proses.equals("delete")) {
				//deletenya hanya update is_delete tadinya 0 jadi 1
				UserModel userModelOld = new UserModel();
				userModelOld = this.userService.detail(userModel.getIdUser());
				
				userModel.setCreatedBy(userModelOld.getCreatedBy());
				userModel.setCreatedDate(userModelOld.getCreatedDate());
				
				userModel.setUpdatedBy(this.getUserModel().getUsername());
				userModel.setUpdatedDate(new Date());
				
				userModel.setUsername(userModelOld.getUsername());
				userModel.setPassword(userModelOld.getPassword());
				userModel.setEmployee_id(userModelOld.getEmployee_id());
				userModel.setIdRole(userModelOld.getIdRole());
				
				userModel.setIsDelete(1);
				
				this.userService.update(userModel);
			} else {

			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("result", proses);

		return "user";
	}

	@RequestMapping(value = "user/list")
	public String list(Model model) {

		List<UserModel> user = null;

		try {
			user = this.userService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("userList", user);

		return "user/list";

	}
	
	@RequestMapping(value = "user/detail")
	public String detail(Model model, HttpServletRequest request) {
	
		Integer idUser = Integer.valueOf(request.getParameter("idUser"));
		UserModel userModel = new UserModel();
		
		List<RoleModel> role = new ArrayList<RoleModel>();
		List<EmployeeModel> employee  = new ArrayList<EmployeeModel>();
		
		
		try {
			userModel = this.userService.detail(idUser);
			role = this.roleService.list();
			employee = this.employeeService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("userModel", userModel);
		model.addAttribute("roleList", role);
		model.addAttribute("employeeList", employee);
		
		return "user/detail";
		
	}
	
	@RequestMapping(value = "user/edit")
	public String edit(Model model, HttpServletRequest request) {
	
		Integer idUser = Integer.valueOf(request.getParameter("idUser"));
		UserModel userModel = new UserModel();
		
		List<RoleModel> role = new ArrayList<RoleModel>();
		List<EmployeeModel> employee  = new ArrayList<EmployeeModel>();
		
		try {
			userModel = this.userService.detail(idUser);
			role = this.roleService.list();
			employee = this.employeeService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("roleList", role);
		model.addAttribute("employeeList", employee);
		model.addAttribute("userModel", userModel);
		
		return "user/edit";
		
	}
	
	@RequestMapping(value = "user/delete")
	public String delete(Model model, HttpServletRequest request) {
	
		Integer idUser = Integer.valueOf(request.getParameter("idUser"));
		UserModel userModel = new UserModel();
		
		List<RoleModel> role = new ArrayList<RoleModel>();
		List<EmployeeModel> employee  = new ArrayList<EmployeeModel>();
		
		
		try {
			userModel = this.userService.detail(idUser);
			role = this.roleService.list();
			employee = this.employeeService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("roleList", role);
		model.addAttribute("employeeList", employee);
		model.addAttribute("userModel", userModel);
		
		return "user/delete";
		
	}
	
	
	
	
	

}
