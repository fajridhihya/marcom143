package com.spring.marcom143.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.spring.marcom143.dao.CompanyDao;
import com.spring.marcom143.model.CompanyModel;

/*repository berfungsi untuk konek ke tablenya*/
@Repository
public class CompanyDaoImpl implements CompanyDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insert(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		//Session importnya yg hibernate
				Session session = this.sessionFactory.getCurrentSession();
				
				/*skrip queri insert into tp dalam bentuk hibernate*/
				session.save(companyModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CompanyModel> list() throws Exception {
		// TODO Auto-generated method stub
		//sessionFactory.getCurrentSession() fungsi utk inisiasi skrip querinya dgn fungsi hibernate
		Session session = this.sessionFactory.getCurrentSession();

		/* session.createQuery adalah skrip queri dari select * from M_COMPANY */
		List<CompanyModel> result = session.createQuery("from CompanyModel where isDelete = 0").list();
		return result;
	}

	@Override
	public void update(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.update adalah skrip queri dari update M_COMPANY set kolom1=nilai1,
		 * kolom2=nilai2 where primaryKey=nilaiPrimaryKey
		 */
		session.update(companyModel);
	}

	@Override
	public void delete(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.delete adalah skrip query dari delete from M_COMPANY where
		 * primaryKey = nilaiPrimaryKey
		 */
		session.delete(companyModel);
	}

	@Override
	public CompanyModel detailByCode(String company_code) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		CompanyModel result = null;
		try {
			result = (CompanyModel) session.createQuery("from CompanyModel where company_code='"+company_code+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return result;
	}

	@Override
	public CompanyModel detailByID(Integer company_id) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		CompanyModel result = session.get(CompanyModel.class, company_id);
		return result;
	}
//
//	@Override
//	public int getIdMax() {
//		// TODO Auto-generated method stub
//		Session session = this.sessionFactory.getCurrentSession();
//		int result = session.createQuery("from CompanyModel where isDelete = 0").getMaxResults();
//		return result;
//		
//	}
	
	

}
