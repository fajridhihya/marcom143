package com.spring.marcom143.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.RoleModel;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.RoleService;
import com.spring.marcom143.tools.KodeGenerator;


@Controller
public class RoleController extends BaseController{
	
	@Autowired
	private RoleService roleService;
	@Autowired
	private MenuService menuService;

	
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	@RequestMapping (value="role")
	public String role(Model model) {
		this.accessLogin(model);
		return "role";
	}
	
	@RequestMapping(value="role/tambah")
	public String tambah(Model model) throws Exception {
		//Skrip untuk generate Kode otomatis
				String kodeRoleGenerator = "";
				Boolean cek = false;

				while(cek==false){
					
					RoleModel roleModel = new RoleModel();
					// kode digenerate dengan inisial namanya, semisal SUP
					// ini kode akan dihasilkan dari kelas KodeGenerator
					kodeRoleGenerator = KodeGenerator.generator("ROL");
					
					//setelah itu dicek dlu apakah kode hasil generatenya sudah ada di database
					roleModel = this.roleService.detailByCode(kodeRoleGenerator);
					
					//jika benar maka looping while berhenti, dan kode terakhir generate 
					//akan dijadikan kode yang ditampilkan di jspnya
					if(roleModel==null){
						cek = true;
					}
					
					//kodeSupplierGenerator akan dikirim ke pop up tambah supplier jsp
					//dimana akan mengisi otomatis nilainya
					model.addAttribute("kodeRoleGenerator", kodeRoleGenerator);
					
				}
		
		return "role/add";
	}
	
	
	@RequestMapping(value="role/simpan")
	private String simpan(@ModelAttribute RoleModel roleModel, HttpServletRequest request, Model model) {
		String proses = request.getParameter("proses");
		
		try {
			
			if (proses.equals("insert")) {
				//Set created by and on
				roleModel.setCreatedByRole(this.getUserModel().getUsername());
				roleModel.setCreatedDateRole(new Date());
				
				//set is_delete defaultnya 0
				roleModel.setIsDeleteRole(0);
		
				this.roleService.insert(roleModel);
			}
			else if (proses.equals("update")) {
				//set modified by and on
				RoleModel roleModelOld = new RoleModel();
				roleModelOld = this.roleService.detailById(roleModel.getIdRole());
				
				roleModel.setCreatedByRole(roleModelOld.getCreatedByRole());
				roleModel.setCreatedDateRole(roleModelOld.getCreatedDateRole());
				roleModel.setIsDeleteRole(roleModelOld.getIsDeleteRole());
				
				roleModel.setUpdatedByRole(this.getUserModel().getUsername());
				roleModel.setUpdatedDateRole(new Date());
				
				this.roleService.update(roleModel);
			}
			else if (proses.equals("delete")) {
				//deletenya hanya update is_delete tdnya 0 jd 1
				RoleModel roleModelOld = new RoleModel();
				roleModelOld = this.roleService.detailById(roleModel.getIdRole());
				
				roleModel.setCreatedByRole(roleModelOld.getCreatedByRole());
				roleModel.setCreatedDateRole(roleModelOld.getCreatedDateRole());
				
				roleModel.setUpdatedByRole(this.getUserModel().getUsername());
				roleModel.setUpdatedDateRole(new Date());
				
				roleModel.setIsDeleteRole(1);
				
				this.roleService.update(roleModel);
				//this.roleService.delete(roleModel);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("result",proses);
		return "role";
	}
	
	@RequestMapping(value="role/list")
	private String list(Model model) {
		//membuat object list dari class supplier model
		//lisnya pilih dari java.util
		List<RoleModel> roles = null;

		try {
			// object items diisi data dari method get
			roles = this.roleService.list();
		} catch (Exception e) {
			
		}

		model.addAttribute("roleList", roles);
		return "role/list";
	}
	
	
	@RequestMapping(value="role/detail")
	private String detail(HttpServletRequest request, Model model) {
		Integer idRole = Integer.valueOf(request.getParameter("idRole"));
		RoleModel roleModel = new RoleModel();
		try {
			roleModel = this.roleService.detailById(idRole);
		} catch (Exception e) {
			// TODO: handle exception
		}
		model.addAttribute("roleModel", roleModel);
		return "role/detail";
	}
	
	//action untuk menampilkan pop up form detail
		@RequestMapping(value="role/edit")
		private String edit(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer idRole = Integer.valueOf(request.getParameter("idRole"));
			RoleModel roleModel = new RoleModel();
			
			try {
					
				roleModel = this.roleService.detailById(idRole);
						
			} catch (Exception e) {
				// TODO: handle exception
			}
				
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("roleModel",roleModel);
			return "role/edit";

		}
		@RequestMapping(value="role/delete")
		private String delete(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer idRole = Integer.valueOf(request.getParameter("idRole"));
			RoleModel roleModel = new RoleModel();
			
			try {
					
				roleModel = this.roleService.detailById(idRole);
						
			} catch (Exception e) {
				// TODO: handle exception
			}
					
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("roleModel",roleModel);
			return "role/delete";

		}
}
