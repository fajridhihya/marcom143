package com.spring.marcom143.dao;

import java.util.List;

import com.spring.marcom143.model.RoleModel;

public interface RoleDao {
	public void insert(RoleModel roleModel) throws Exception;
	public List<RoleModel>list() throws Exception;
	public RoleModel detailByCode(String codeRole) throws Exception;
	public RoleModel detailById(Integer idRole) throws Exception;
	public void update(RoleModel roleModel) throws Exception;
	public void delete(RoleModel roleModel) throws Exception;
}
