package com.spring.marcom143.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.spring.marcom143.dao.TSouvenirDao;
import com.spring.marcom143.model.TSouvenirModel;

/*repository berfungsi untuk konek ke tablenya*/
@Repository
public class TSouvenirDaoImpl implements TSouvenirDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insert(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		//Session importnya yg hibernate
				Session session = this.sessionFactory.getCurrentSession();
				
				/*skrip queri insert into tp dalam bentuk hibernate*/
				session.save(tsouvenirModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TSouvenirModel> list() throws Exception {
		// TODO Auto-generated method stub
		//sessionFactory.getCurrentSession() fungsi utk inisiasi skrip querinya dgn fungsi hibernate
		Session session = this.sessionFactory.getCurrentSession();

		/* session.createQuery adalah skrip queri dari select * from T_SOUVENIR */
		List<TSouvenirModel> result = session.createQuery("from TSouvenirModel").list();
		return result;
	}

	@Override
	public void update(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.update adalah skrip queri dari update T_SOUVENIR set kolom1=nilai1,
		 * kolom2=nilai2 where primaryKey=nilaiPrimaryKey
		 */
		session.update(tsouvenirModel);
	}

	@Override
	public void delete(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.delete adalah skrip query dari delete from T_SOUVENIR where
		 * primaryKey = nilaiPrimaryKey
		 */
		session.delete(tsouvenirModel);
	}

	@Override
	public TSouvenirModel detailByCode(String tsouvenir_code) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		TSouvenirModel result = null;
		try {
			result = (TSouvenirModel) session.createQuery("from TSouvenirModel where tsouvenir_code='"+tsouvenir_code+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return result;
	}

	@Override
	public TSouvenirModel detailByID(Integer tsouvenir_id) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		TSouvenirModel result = session.get(TSouvenirModel.class, tsouvenir_id);
		return result;
	}
	
	

}
