package com.spring.marcom143.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table (name="MST_MENU")
public class MenuModel {
	public Integer idMenu;
	public String codeMenu;
	public String nameMenu;
	public String controllerMenu;
	public Integer isDeleteMenu;
	public String createdByMenu;
	public Date createdDateMenu;
	public String updatedByMenu;
	public Date updatedDateMenu;
	public Integer parentId;
	
	@Id
	@Column(name="ID_MENU")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="MST_MENU")
	@TableGenerator(name="MST_MENU", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
					pkColumnValue="MST_MENU", valueColumnName="SEQUENCE_VALUE",
					allocationSize=1, initialValue=1)
	public Integer getIdMenu() {
		return idMenu;
	}
	public void setIdMenu(Integer idMenu) {
		this.idMenu = idMenu;
	}
	
	@Column(name="CODE_MENU")
	public String getCodeMenu() {
		return codeMenu;
	}

	public void setCodeMenu(String codeMenu) {
		this.codeMenu = codeMenu;
	}
	
	@Column(name="NAME_MENU")
	public String getNameMenu() {
		return nameMenu;
	}
	public void setNameMenu(String nameMenu) {
		this.nameMenu = nameMenu;
	}
	
	@Column(name="CONTROLLER_MENU")
	public String getControllerMenu() {
		return controllerMenu;
	}
	public void setControllerMenu(String controllerMenu) {
		this.controllerMenu = controllerMenu;
	}
	
	@Column(name="IS_DELETE_MENU")
	public Integer getIsDeleteMenu() {
		return isDeleteMenu;
	}
	public void setIsDeleteMenu(Integer isDeleteMenu) {
		this.isDeleteMenu = isDeleteMenu;
	}
	
	@Column(name="CREATED_BY_MENU")
	public String getCreatedByMenu() {
		return createdByMenu;
	}
	public void setCreatedByMenu(String createdByMenu) {
		this.createdByMenu = createdByMenu;
	}
	
	@Column(name="CREATED_DATE_MENU")
	public Date getCreatedDateMenu() {
		return createdDateMenu;
	}
	public void setCreatedDateMenu(Date createdDateMenu) {
		this.createdDateMenu = createdDateMenu;
	}
	
	
	@Column(name="UPDATED_BY_MENU")
	public String getUpdatedByMenu() {
		return updatedByMenu;
	}
	public void setUpdatedByMenu(String updatedByMenu) {
		this.updatedByMenu = updatedByMenu;
	}
	
	
	@Column(name="UPDATED_DATE_MENU")
	public Date getUpdatedDateMenu() {
		return updatedDateMenu;
	}
	public void setUpdatedDateMenu(Date updatedDateMenu) {
		this.updatedDateMenu = updatedDateMenu;
	}
	
	@Column(name="PARENT_ID")
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	
	
}
