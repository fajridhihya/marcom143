package com.spring.marcom143.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
/*import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;*/
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/*import javax.persistence.TableGenerator;*/
import javax.persistence.TableGenerator;

@Entity
@Table(name = "MST_SOUVENIR")
public class SouvenirModel {
	private Integer idSouvenir;
	private String codeSouvenir;
	private String nameSouvenir;
	private String description;
	
	//join table unit
	private String idUnit;
	private UnitModel unitModel;
	
	
	private Integer isDeleteSouvenir;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	
	@Id
	@Column(name="ID_SOUVENIR")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="MST_SOUVENIR") //karena oracle ga bisa ake increment kyk sql
	@TableGenerator(name="MST_SOUVENIR", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
			pkColumnValue="MST_SOUVENIR", valueColumnName="SEQUENCE_VALUE",
			allocationSize=1, initialValue=1)
	public Integer getIdSouvenir() {
		return idSouvenir;
	}
	public void setIdSouvenir(Integer idSouvenir) {
		this.idSouvenir = idSouvenir;
	}
	
	@Column(name="CODE_SOUVENIR")
	public String getCodeSouvenir() {
		return codeSouvenir;
	}
	public void setCodeSouvenir(String codeSouvenir) {
		this.codeSouvenir = codeSouvenir;
	}
	
	@Column(name="NAME_SOUVENIR")
	public String getNameSouvenir() {
		return nameSouvenir;
	}
	public void setNameSouvenir(String nameSouvenir) {
		this.nameSouvenir = nameSouvenir;
	}
	
	@Column(name="DESCRIPTION")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Column(name="ID_UNIT")
	public String getIdUnit() {
		return idUnit;
	}
	public void setIdUnit(String idUnit) {
		this.idUnit = idUnit;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_UNIT", nullable = false, updatable = false, insertable = false)
	public UnitModel getUnitModel() {
		return unitModel;
	}
	public void setUnitModel(UnitModel unitModel) {
		this.unitModel = unitModel;
	}
	
	@Column(name="IS_DELETE_SOUVENIR")
	public Integer getIsDeleteSouvenir() {
		return isDeleteSouvenir;
	}
	public void setIsDeleteSouvenir(Integer isDeleteSouvenir) {
		this.isDeleteSouvenir = isDeleteSouvenir;
	}
	
	@Column(name="CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name="CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name="UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
