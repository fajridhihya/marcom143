package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.SouvenirModel;
import com.spring.marcom143.model.TSouvenirItemModel;
import com.spring.marcom143.model.TSouvenirModel;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.SouvenirService;
import com.spring.marcom143.service.TSouvenirItemService;
import com.spring.marcom143.service.TSouvenirService;

@Controller
public class TSouvenirItemController extends BaseController{

	@Autowired
	private TSouvenirItemService tsouveniritemService;
	
	@Autowired
	private SouvenirService souvenirService;
	
	@Autowired
	private TSouvenirService tsouvenirService;
	
	@Autowired
	private MenuService menuService;

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	/*requestmapping value maksdnya ketika diklik url/ action dari TSouvenirItem.html */
	/*String TSouvenirItem(Model model) maksudnya ini adalah method TSouvenirItem*/
	@RequestMapping(value="tsouveniritem")
	public String TSouvenirItem(Model model) {
		this.accessLogin(model);
		// return TSouvenirItem mksdnya memanggil TSouvenirItem.jsp di folder web-inf/jsp
		return "tsouveniritem";		
	}
	
	//action url memanggil tambah TSouvenirItem.jsp
	@RequestMapping(value = "tsouveniritem/tambah")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub
		
		List<SouvenirModel> souvenirs = new ArrayList<SouvenirModel>();
		List<TSouvenirModel> tsouvenirs = new ArrayList<TSouvenirModel>();
		
		try {
			souvenirs = this.souvenirService.list();
			tsouvenirs = this.tsouvenirService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("souvenirList",souvenirs);
		model.addAttribute("tsouvenirList",tsouvenirs);
		
		return "tsouveniritem/add";
	}
		
		//action url memanggil tambah TSouvenirItem.jsp
		@RequestMapping(value="tsouveniritem/simpan")
		private String simpan(@ModelAttribute TSouvenirItemModel TSouvenirItemModel, HttpServletRequest request, Model model) {
			// TODO Auto-generated method stub
			/*variable proses menentukan apakah kita ingin insert data baru, update data lama, atau hapus data*/
			String proses = request.getParameter("proses");
			
			/*dibutuhkan try catch karena memanggil service*/
			try {
				
				if (proses.equals("insert")) {
					// Set create and on
					TSouvenirItemModel.setCreatedBy(this.getUserModel().getUsername());
					TSouvenirItemModel.setCreatedDate(new Date());
					
					//Set is_delete defaultnya 0 --> artinya belum terhapus
					TSouvenirItemModel.setIsDelete(0);
					
					this.tsouveniritemService.insert(TSouvenirItemModel);
					
				}else if (proses.equals("update")) {
					// Set modified by and on
					TSouvenirItemModel TSouvenirItemModelOld = new TSouvenirItemModel();
					TSouvenirItemModelOld = this.tsouveniritemService.detailByID(TSouvenirItemModel.getTsouvenir_id_item());
					
					TSouvenirItemModel.setCreatedBy(TSouvenirItemModelOld.getCreatedBy());
					TSouvenirItemModel.setCreatedDate(TSouvenirItemModelOld.getCreatedDate());
					TSouvenirItemModel.setIsDelete(TSouvenirItemModelOld.getIsDelete());
					
					TSouvenirItemModel.setUpdatedBy(this.getUserModel().getUsername());
					TSouvenirItemModel.setUpdatedDate(new Date());
					
					this.tsouveniritemService.update(TSouvenirItemModel);
					
				}else if (proses.equals("delete")) {
					//deletenya hanya update is_delete tdnya 0 jd 1
					TSouvenirItemModel TSouvenirItemModelOld = new TSouvenirItemModel();
					TSouvenirItemModelOld = this.tsouveniritemService.detailByID(TSouvenirItemModel.getTsouvenir_id_item());
					
					TSouvenirItemModel.setCreatedBy(TSouvenirItemModelOld.getCreatedBy());
					TSouvenirItemModel.setCreatedDate(TSouvenirItemModelOld.getCreatedDate());
					
					TSouvenirItemModel.setUpdatedBy(this.getUserModel().getUsername());
					TSouvenirItemModel.setUpdatedDate(new Date());
					
					TSouvenirItemModel.setIsDelete(1);
					
					this.tsouveniritemService.delete(TSouvenirItemModel);
					
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			model.addAttribute("result",proses);
			return "tsouveniritem";
		}
	
		//action untuk menampilkan looping data TSouvenirItem dari table TSouvenirItem
		@RequestMapping(value="tsouveniritem/list")
		private String list(Model model) {
			// membuat object list dari class TSouvenirItem model
			// List nya import dari java.util
			List<TSouvenirItemModel> tsouveniritems = null;

			try {
				// object items diisi data dari method get
				tsouveniritems = this.tsouveniritemService.list();
			} catch (Exception e) {
				//log.error(e.getMessage(), e);
			}

			// datanya kita kirim ke view = jsp,
			// kita buat variable list kemudian diisi dengan object TSouvenirItems
			model.addAttribute("tsouveniritemList", tsouveniritems);
			
			//model.addAttribute(VARIABLE DI JSP, NILAI VARIABLENYA);
			
			return "tsouveniritem/list";
		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="tsouveniritem/detail")
		private String detail(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer tsouvenir_id_item = Integer.valueOf(request.getParameter("tsouvenir_id_item"));
			TSouvenirItemModel tsouveniritemModel = new TSouvenirItemModel();
			
			List<SouvenirModel> souvenirs = new ArrayList<SouvenirModel>();
			List<TSouvenirModel> tsouvenirs = new ArrayList<TSouvenirModel>();
			
			try {
				
				tsouveniritemModel = this.tsouveniritemService.detailByID(tsouvenir_id_item);
				souvenirs = this.souvenirService.list();
				tsouvenirs = this.tsouvenirService.list();
						
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("tsouveniritemModel",tsouveniritemModel);
			
			model.addAttribute("souvenirList",souvenirs);
			model.addAttribute("tsouvenirList",tsouvenirs);
			
			return "tsouveniritem/detail";

		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="tsouveniritem/edit")
		private String edit(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer tsouvenir_id_item = Integer.valueOf(request.getParameter("tsouvenir_id_item"));
			TSouvenirItemModel tsouveniritemModel = new TSouvenirItemModel();
			
			List<SouvenirModel> souvenirs = new ArrayList<SouvenirModel>();
			List<TSouvenirModel> tsouvenirs = new ArrayList<TSouvenirModel>();
			
			try {
					
				tsouveniritemModel = this.tsouveniritemService.detailByID(tsouvenir_id_item);
				souvenirs = this.souvenirService.list();
				tsouvenirs = this.tsouvenirService.list();
						
			} catch (Exception e) {
				// TODO: handle exception
			}
				
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("tsouveniritemModel",tsouveniritemModel);
			
			model.addAttribute("souvenirList",souvenirs);
			model.addAttribute("tsouvenirList",tsouvenirs);
			return "tsouveniritem/edit";

		}
	
		//action untuk menampilkan pop up form detail
	@RequestMapping(value = "tsouveniritem/delete")
	private String delete(HttpServletRequest request, Model model) {
		// TODO Auto-generated method stub
		Integer tsouvenir_id_item = Integer.valueOf(request.getParameter("tsouvenir_id_item"));
		TSouvenirItemModel tsouveniritemModel = new TSouvenirItemModel();

		List<SouvenirModel> souvenirs = new ArrayList<SouvenirModel>();
		List<TSouvenirModel> tsouvenirs = new ArrayList<TSouvenirModel>();

		try {

			tsouveniritemModel = this.tsouveniritemService.detailByID(tsouvenir_id_item);
			souvenirs = this.souvenirService.list();
			tsouvenirs = this.tsouvenirService.list();

		} catch (Exception e) {
			// TODO: handle exception
		}

		// modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
		model.addAttribute("tsouveniritemModel", tsouveniritemModel);

		model.addAttribute("souvenirList", souvenirs);
		model.addAttribute("tsouvenirList", tsouvenirs);
		return "tsouveniritem/delete";

	}
	
}
