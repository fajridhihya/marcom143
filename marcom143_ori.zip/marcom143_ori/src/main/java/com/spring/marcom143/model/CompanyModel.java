package com.spring.marcom143.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="M_COMPANY")
public class CompanyModel {
	
	private Integer company_id;
	private String company_code;
	private String company_name;
	private String company_address;
	private Integer company_phone;
	private String company_email;
	
	private Integer isDelete;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	
	@Id
	@Column(name="COMPANY_ID")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="M_COMPANY") //karena oracle ga bisa ake increment kyk sql
	@TableGenerator(name="M_COMPANY", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
			pkColumnValue="M_COMPANY", valueColumnName="SEQUENCE_VALUE",
			allocationSize=1, initialValue=1)
	public Integer getCompany_id() {
		return company_id;
	}
	public void setCompany_id(Integer company_id) {
		this.company_id = company_id;
	}
	
	@Column(name="COMPANY_CODE")
	public String getCompany_code() {
		return company_code;
	}
	public void setCompany_code(String company_code) {
		this.company_code = company_code;
	}
	@Column(name="COMPANY_NAME")
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	@Column(name="COMPANY_ADDRESS")
	public String getCompany_address() {
		return company_address;
	}
	public void setCompany_address(String company_address) {
		this.company_address = company_address;
	}
	@Column(name="COMPANY_PHONE")
	public Integer getCompany_phone() {
		return company_phone;
	}
	public void setCompany_phone(Integer company_phone) {
		this.company_phone = company_phone;
	}
	@Column(name="COMPANY_EMAIL")
	public String getCompany_email() {
		return company_email;
	}
	public void setCompany_email(String company_email) {
		this.company_email = company_email;
	}
	@Column(name = "IS_DELETE")
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name = "CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name = "UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
