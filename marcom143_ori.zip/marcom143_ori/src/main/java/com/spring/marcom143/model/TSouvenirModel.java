package com.spring.marcom143.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="T_SOUVENIR")
public class TSouvenirModel {
	
	private Integer tsouvenir_id;
	private String tsouvenir_code;
	private String tsouvenir_type;
	
	private Integer employee_id;
	private EmployeeModel employeeModel;
	
	private String tsouvenir_date;
	private String tsouvenir_note;
	
	private Integer isDelete;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	
	@Id
	@Column(name="TSOUVENIR_ID")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="T_SOUVENIR") //karena oracle ga bisa ake increment kyk sql
	@TableGenerator(name="T_SOUVENIR", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
			pkColumnValue="T_SOUVENIR", valueColumnName="SEQUENCE_VALUE",
			allocationSize=1, initialValue=1)
	public Integer getTsouvenir_id() {
		return tsouvenir_id;
	}
	public void setTsouvenir_id(Integer tsouvenir_id) {
		this.tsouvenir_id = tsouvenir_id;
	}
	@Column(name="TSOUVENIR_CODE")
	public String getTsouvenir_code() {
		return tsouvenir_code;
	}
	public void setTsouvenir_code(String tsouvenir_code) {
		this.tsouvenir_code = tsouvenir_code;
	}
	@Column(name="TSOUVENIR_TYPE")
	public String getTsouvenir_type() {
		return tsouvenir_type;
	}
	public void setTsouvenir_type(String tsouvenir_type) {
		this.tsouvenir_type = tsouvenir_type;
	}
	
	@Column(name="EMPLOYEE_ID")
	public Integer getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(Integer employee_id) {
		this.employee_id = employee_id;
	}
	@ManyToOne
	@JoinColumn(name="EMPLOYEE_ID", nullable = false, updatable = false, insertable = false)
	public EmployeeModel getEmployeeModel() {
		return employeeModel;
	}
	public void setEmployeeModel(EmployeeModel employeeModel) {
		this.employeeModel = employeeModel;
	}
	
	@Column(name="TSOUVENIR_RECEIVE_DATE")
	public String getTsouvenir_date() {
		return tsouvenir_date;
	}
	public void setTsouvenir_date(String tsouvenir_date) {
		this.tsouvenir_date = tsouvenir_date;
	}
	@Column(name="TSOUVENIR_NOTE")
	public String getTsouvenir_note() {
		return tsouvenir_note;
	}
	public void setTsouvenir_note(String tsouvenir_note) {
		this.tsouvenir_note = tsouvenir_note;
	}
	@Column(name = "IS_DELETE")
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name = "CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name = "UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}
