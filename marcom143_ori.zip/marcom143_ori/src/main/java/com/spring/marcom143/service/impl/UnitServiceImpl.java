package com.spring.marcom143.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.marcom143.dao.UnitDao;
import com.spring.marcom143.model.UnitModel;
import com.spring.marcom143.service.UnitService;

@Service
@Transactional
public class UnitServiceImpl implements UnitService {
	@Autowired
	private UnitDao unitDao;

	@Override
	public void insert(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		this.unitDao.insert(unitModel);
	}

	@Override
	public List<UnitModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.unitDao.list();
	}

	@Override
	public UnitModel detailByCode(String codeUnit) throws Exception {
		// TODO Auto-generated method stub
		return this.unitDao.detailByCode(codeUnit);
	}

	@Override
	public void update(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		this.unitDao.update(unitModel);
	}

	@Override
	public void delete(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		this.unitDao.delete(unitModel);
	}

	@Override
	public UnitModel detailByID(Integer idUnit) throws Exception {
		// TODO Auto-generated method stub
		return this.unitDao.detailByID(idUnit);
	}
	
	
}
