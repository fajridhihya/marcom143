package com.spring.marcom143.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.marcom143.dao.MenuAccessDao;
import com.spring.marcom143.model.MenuAccessModel;

@Repository
public class MenuAccessDaoImpl implements MenuAccessDao{

	@Autowired
	private SessionFactory SessionFactory;
	
	@Override
	public void insert(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.save(menuAccessModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenuAccessModel> list() throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		List<MenuAccessModel> result = session.createQuery("from MenuAccessModel where isDelete = 0").list();
		return result;
	}

	@Override
	public MenuAccessModel detail(Integer idMenuAccess) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		MenuAccessModel result = session.get(MenuAccessModel.class, idMenuAccess);
		return result;
	}

	@Override
	public void update(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.update(menuAccessModel);
	}

	@Override
	public void delete(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.delete(menuAccessModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenuAccessModel> cekMenuAccess(Integer idRole, Integer idMenu) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		List<MenuAccessModel> result = session.createQuery("from MenuAccessModel where idRole ="+idRole+" and idMenu="+idMenu+" ").list();
		return result;
	}

}
