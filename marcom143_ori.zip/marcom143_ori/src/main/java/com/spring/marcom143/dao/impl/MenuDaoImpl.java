package com.spring.marcom143.dao.impl;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.marcom143.dao.MenuDao;
import com.spring.marcom143.model.MenuModel;


@SuppressWarnings("deprecation")
@Repository
public class MenuDaoImpl implements MenuDao{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void insert(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.save(menuModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MenuModel> list() throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		List<MenuModel>result = session.createQuery("from MenuModel").list();
		return result;
	}
	
	@Override
	public void update(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(menuModel);
	}

	@Override
	public void delete(MenuModel menuModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(menuModel);
	}

	@Override
	public MenuModel detailByCode(String codeMenu) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		MenuModel result = null;
		try {
			result = (MenuModel) session.createQuery("from MenuModel where codeMenu = '"+codeMenu+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return result;
	}

	@Override
	public MenuModel detailById(Integer idMenu) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		MenuModel result = session.get(MenuModel.class, idMenu);
		return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })

	@Override
	public List<MenuModel> getMenuLogin(Integer idRole) throws Exception {
		// TODO Auto-generated method stub
		String sqlquery =  " select "
				+ " 	m.id_menu, "
				+ "		code_menu,"
				+ "		m.controller_menu,"
				+ "		m.created_by_menu,"
				+ "		m.created_date_menu,"
				+ "		m.is_delete_menu,"
				+ "		m.name_menu,"
				+ " 	m.parent_id,"
				+ "		m.updated_by_menu,"
				+ "		m.updated_date_menu"
				+ " from mst_menu m "
				+ " join mst_menu_access ma "
				+ "  	on ma.m_id_menu = m.id_menu "
				+ "	where ma.m_id_role ="+idRole+" "
				+ " order by m.name_menu asc ";

		Session session = sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery(sqlquery);
		query.addEntity(MenuModel.class);
		List<MenuModel> result = query.list();
		return result;
		}
	
	

}
