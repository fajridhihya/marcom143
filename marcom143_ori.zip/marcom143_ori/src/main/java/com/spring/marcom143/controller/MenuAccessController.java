package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuAccessModel;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.RoleModel;
import com.spring.marcom143.service.MenuAccessService;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.RoleService;

@Controller
public class MenuAccessController extends BaseController {

	@Autowired
	private MenuAccessService menuAccessService;

	@Autowired
	private RoleService roleService;
	
	// service untuk menampilkan menu sidebar
	@Autowired
	private MenuService menuService;

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login

	@RequestMapping(value = "menu_access")
	public String menuAccess(Model model) {
		// this.accessLogin(model) memanggil method accessLogin
		this.accessLogin(model);
		return "menu_access";

	}

	@RequestMapping(value = "menu_access/tambah")
	public String tambah(Model model) {

		List<RoleModel> role = new ArrayList<RoleModel>();
		List<MenuModel> menu = new ArrayList<MenuModel>();

		try {
			role = this.roleService.list();
			menu = this.menuService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("roleList", role);
		model.addAttribute("menuList", menu);
		return "menu_access/add";
	}

	@RequestMapping(value = "menu_access/simpan")
	public String simpan(@ModelAttribute MenuAccessModel menuAccessModel, HttpServletRequest request, Model model) {

		String proses = request.getParameter("proses");

		try {
			if (proses.equals("insert")) {
				
				List<MenuAccessModel> menuAccessModelList = new ArrayList<MenuAccessModel>();
				Integer idRole = menuAccessModel.getIdRole();
				Integer idMenu = menuAccessModel.getIdMenu();
				menuAccessModelList = this.menuAccessService.cekMenuAccess(idRole, idMenu);
				
				if (menuAccessModelList.size()==0) {
					// size 0 artinya ada data di db
					// Set create and on
					menuAccessModel.setCreatedBy(this.getUserModel().getUsername());
					menuAccessModel.setCreatedDate(new Date());

					// set is_delete defaultnya 0
					menuAccessModel.setIsDelete(0);
					
					this.menuAccessService.insert(menuAccessModel);
					
					
				}else {
					proses = "exist";
				}
				
			} else if (proses.equals("update")) {
				List<MenuAccessModel> menuAccessModelList = new ArrayList<MenuAccessModel>();
				Integer idRole = menuAccessModel.getIdRole();
				Integer idMenu = menuAccessModel.getIdMenu();
				menuAccessModelList = this.menuAccessService.cekMenuAccess(idRole, idMenu);
				
				if (menuAccessModelList.size()==0) {
					// Set modified by and on
					MenuAccessModel menuAccessModelOld = new MenuAccessModel();
					menuAccessModelOld = this.menuAccessService.detail(menuAccessModel.getIdMenuAccess());

					menuAccessModel.setCreatedBy(menuAccessModelOld.getCreatedBy());
					menuAccessModel.setCreatedDate(menuAccessModelOld.getCreatedDate());
					menuAccessModel.setIsDelete(menuAccessModelOld.getIsDelete());

					menuAccessModel.setUpdatedBy(this.getUserModel().getUsername());
					menuAccessModel.setUpdatedDate(new Date());

					this.menuAccessService.update(menuAccessModel);
				} else {
					proses = "exist";
				}
				
				
			} else if (proses.equals("delete")) {
				MenuAccessModel menuAccessModelOld = new MenuAccessModel();
				menuAccessModelOld = this.menuAccessService.detail(menuAccessModel.getIdMenuAccess());

				menuAccessModel.setCreatedBy(menuAccessModelOld.getCreatedBy());
				menuAccessModel.setCreatedDate(menuAccessModelOld.getCreatedDate());

				menuAccessModel.setUpdatedBy(this.getUserModel().getUsername());
				menuAccessModel.setUpdatedDate(new Date());
				menuAccessModel.setIdRole(menuAccessModelOld.getIdRole());

				menuAccessModel.setIsDelete(1);

				this.menuAccessService.update(menuAccessModel);
			} else {

			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("result", proses);

		return "menu_access";
	}

	@RequestMapping(value = "menu_access/list")
	public String list(Model model) {
		List<MenuAccessModel> menuAccess = null;

		try {
			menuAccess = this.menuAccessService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("menuAccessList", menuAccess);

		return "menu_access/list";

	}

	@RequestMapping(value = "menu_access/detail")
	public String detail(HttpServletRequest request, Model model) {

		Integer idMenuAccess = Integer.valueOf(request.getParameter("idMenuAccess"));
		MenuAccessModel menuAccessModel = new MenuAccessModel();

		List<RoleModel> role = new ArrayList<RoleModel>();
		List<MenuModel> menu = new ArrayList<MenuModel>();

		try {
			menuAccessModel = this.menuAccessService.detail(idMenuAccess);
			role = this.roleService.list();
			menu = this.menuService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("roleList", role);
		model.addAttribute("menuList", menu);
		model.addAttribute("menuAccessModel", menuAccessModel);

		return "menu_access/detail";
	}

	@RequestMapping(value = "menu_access/edit")
	public String edit(HttpServletRequest request, Model model) {

		Integer idMenuAccess = Integer.valueOf(request.getParameter("idMenuAccess"));
		MenuAccessModel menuAccessModel = new MenuAccessModel();

		List<RoleModel> role = new ArrayList<RoleModel>();
		List<MenuModel> menu = new ArrayList<MenuModel>();

		try {
			menuAccessModel = this.menuAccessService.detail(idMenuAccess);
			role = this.roleService.list();
			menu = this.menuService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("roleList", role);
		model.addAttribute("menuList", menu);
		model.addAttribute("menuAccessModel", menuAccessModel);

		return "menu_access/edit";
	}

	@RequestMapping(value = "menu_access/delete")
	public String delete(HttpServletRequest request, Model model) {

		Integer idMenuAccess = Integer.valueOf(request.getParameter("idMenuAccess"));
		MenuAccessModel menuAccessModel = new MenuAccessModel();

		List<RoleModel> role = new ArrayList<RoleModel>();
		List<MenuModel> menu = new ArrayList<MenuModel>();

		try {
			menuAccessModel = this.menuAccessService.detail(idMenuAccess);
			role = this.roleService.list();
			menu = this.menuService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}

		model.addAttribute("roleList", role);
		model.addAttribute("menuList", menu);
		model.addAttribute("menuAccessModel", menuAccessModel);

		return "menu_access/delete";
	}

}
