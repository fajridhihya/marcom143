package com.spring.marcom143.dao;
import java.util.List;

import com.spring.marcom143.model.CompanyModel;

public interface CompanyDao {
	public void insert(CompanyModel companyModel) throws Exception;
	public List<CompanyModel> list() throws Exception;
//	public int getIdMax();
	
	public CompanyModel detailByCode(String company_code) throws Exception;
	public CompanyModel detailByID(Integer company_id) throws Exception;
	
	public void update(CompanyModel companyModel) throws Exception;
	public void delete(CompanyModel companyModel) throws Exception;
}
