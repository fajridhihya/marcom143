package com.spring.marcom143.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.tools.KodeGenerator;

@Controller
public class MenuController extends BaseController {
	@Autowired 
	private MenuService menuService;
	
	
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getMenuLogin(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	@RequestMapping (value="menu")
	public String menu(Model model) {
		this.accessLogin(model);
		return "menu";
	}
	
	@RequestMapping(value="menu/tambah")
	public String tambah(Model model) throws Exception {
		//Skrip untuk generate Kode otomatis
		String kodeMenuGenerator = "";
		Boolean cek = false;

		while(cek==false){
			
			MenuModel menuModel = new MenuModel();
			// kode digenerate dengan inisial namanya, semisal SUP
			// ini kode akan dihasilkan dari kelas KodeGenerator
			kodeMenuGenerator = KodeGenerator.generator("ROL");
			
			//setelah itu dicek dlu apakah kode hasil generatenya sudah ada di database
			menuModel = this.menuService.detailByCode(kodeMenuGenerator);
			
			//jika benar maka looping while berhenti, dan kode terakhir generate 
			//akan dijadikan kode yang ditampilkan di jspnya
			if(menuModel==null){
				cek = true;
			}
			
			//kodeMenuGenerator akan dikirim ke pop up tambah menu jsp
			//dimana akan mengisi otomatis nilainya
			model.addAttribute("kodeMenuGenerator", kodeMenuGenerator);
			
		}
		
		return "menu/add";
	}
	
	
	@RequestMapping(value="menu/simpan")
	private String simpan(@ModelAttribute MenuModel menuModel, HttpServletRequest request, Model model) {
		String proses = request.getParameter("proses");
		
		try {
			
			if (proses.equals("insert")) {
				menuModel.setCreatedByMenu(this.getUserModel().getUsername());
				menuModel.setCreatedDateMenu(new Date());
				//set is_delete defaultnya 0
				menuModel.setIsDeleteMenu(0);
				this.menuService.insert(menuModel);
			}
			else if (proses.equals("update")) {
				MenuModel menuModelOld = new MenuModel();
				menuModelOld = this.menuService.detailById(menuModel.getIdMenu());
				
				menuModel.setCreatedByMenu(menuModelOld.getCreatedByMenu());
				menuModel.setCreatedDateMenu(menuModelOld.getCreatedDateMenu());
				menuModel.setIsDeleteMenu(menuModelOld.getIsDeleteMenu());
				
				menuModel.setUpdatedByMenu(this.getUserModel().getUsername());
				menuModel.setUpdatedDateMenu(new Date());
				this.menuService.update(menuModel);
			}
			else if (proses.equals("delete")) {
				//deletenya hanya update is_delete tdnya 0 jd 1
				MenuModel menuModelOld = new MenuModel();
				menuModelOld = this.menuService.detailById(menuModel.getIdMenu());
				
				menuModel.setCreatedByMenu(menuModelOld.getCreatedByMenu());
				menuModel.setCreatedDateMenu(menuModelOld.getCreatedDateMenu());
				
				menuModel.setUpdatedByMenu(this.getUserModel().getUsername());
				menuModel.setUpdatedDateMenu(new Date());
				
				menuModel.setIsDeleteMenu(1);
				this.menuService.update(menuModel);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("result",proses);
		return "menu";
	}
	
	@RequestMapping(value="menu/list")
	private String list(Model model) {
		//membuat object list dari class menu model
		//lisnya pilih dari java.util
		List<MenuModel> menus = null;

		try {
			// object items diisi data dari method get
			menus = this.menuService.list();
		} catch (Exception e) {
			
		}

		// datanya kita kirim ke view =jsp,
		// kita buat variable list kemudian diisi dengan object menus
		model.addAttribute("menuList", menus);
		
		//model.addAttribute("variable di jsp", nilai Variablenya);
		//model.addAttribute yaitu untuk mengirim data dari kontroler ke jsp
		return "menu/list";
	}
	@RequestMapping(value="menu/detail")
	private String detail(HttpServletRequest request, Model model) {
		Integer idMenu = Integer.valueOf(request.getParameter("idMenu"));
		MenuModel menuModel = new MenuModel();
		try {
			menuModel = this.menuService.detailById(idMenu);
		} catch (Exception e) {
			// TODO: handle exception
		}
		model.addAttribute("menuModel", menuModel);
		return "menu/detail";
	}
	
	@RequestMapping(value="menu/edit")
	private String edit(HttpServletRequest request,Model model) {
		// TODO Auto-generated method stub
		Integer idMenu = Integer.valueOf(request.getParameter("idMenu"));
		MenuModel menuModel = new MenuModel();
		
		try {
				
			menuModel = this.menuService.detailById(idMenu);
					
		} catch (Exception e) {
			// TODO: handle exception
		}
			
		//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
		model.addAttribute("menuModel",menuModel);
		return "menu/edit";

	}
	@RequestMapping(value="menu/delete")
	private String delete(HttpServletRequest request,Model model) {
		// TODO Auto-generated method stub
		Integer idMenu = Integer.valueOf(request.getParameter("idMenu"));
		MenuModel menuModel = new MenuModel();
		
		try {
				
			menuModel = this.menuService.detailById(idMenu);
					
		} catch (Exception e) {
			// TODO: handle exception
		}
				
		//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
		model.addAttribute("menuModel",menuModel);
		return "menu/delete";

	}
}
