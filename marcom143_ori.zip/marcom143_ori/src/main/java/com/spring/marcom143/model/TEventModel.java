package com.spring.marcom143.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="T_EVENT")
public class TEventModel {
	private Integer idEvent;
	private String nameEvent;
	
	@Id
	@Column(name="ID_EVENT")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="T_EVENT") //karena oracle ga bisa ake increment kyk sql
	@TableGenerator(name="T_EVENT", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
			pkColumnValue="T_EVENT", valueColumnName="SEQUENCE_VALUE",
			allocationSize=1, initialValue=1)
	public Integer getIdEvent() {
		return idEvent;
	}
	public void setIdEvent(Integer idEvent) {
		this.idEvent = idEvent;
	}
	
	@Column(name="NAME_EVENT")
	public String getNameEvent() {
		return nameEvent;
	}
	public void setNameEvent(String nameEvent) {
		this.nameEvent = nameEvent;
	}
	
	
}
