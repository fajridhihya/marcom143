package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.SouvenirModel;
import com.spring.marcom143.model.UnitModel;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.SouvenirService;
import com.spring.marcom143.service.UnitService;
import com.spring.marcom143.tools.KodeGenerator;

@Controller
public class SouvenirController extends BaseController {
	
	@Autowired
	private SouvenirService souvenirService;
	@Autowired
	private MenuService menuService;
	
	@Autowired
	private UnitService unitService;
	
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	@RequestMapping(value="souvenir")
	public String index(Model model) {
		this.accessLogin(model);
		return "souvenir";
	}
	
	@RequestMapping(value="souvenir/add")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub

		List<UnitModel> units = new ArrayList<UnitModel>();
		
		units = this.unitService.list();
		
		String codeSouvenirGenerator = "";
		Boolean cek = false;
		
		while (cek == false) {
			SouvenirModel souvenirModel = new SouvenirModel();
			
			codeSouvenirGenerator = KodeGenerator.generator("SV");
			
			souvenirModel = this.souvenirService.detailByCode(codeSouvenirGenerator);
			
			if (souvenirModel == null) {
				cek = true;
			}
			
			model.addAttribute("codeSouvenirGenerator", codeSouvenirGenerator);
			
		}
		
		model.addAttribute("unitList", units);
		return "souvenir/add";
	}
	
	@RequestMapping(value="souvenir/simpan")
	private String simpan(@ModelAttribute SouvenirModel souvenirModel, HttpServletRequest request, Model model) {
		// TODO Auto-generated method stub
		
		String proses = request.getParameter("proses");
		
		try {
			
			if (proses.equals("insert")) {
				//set created
				souvenirModel.setCreatedBy(this.getUserModel().getUsername());
				souvenirModel.setCreatedDate(new Date());
				
				//set isdelete
				souvenirModel.setIsDeleteSouvenir(0);
				
				this.souvenirService.insert(souvenirModel);
				
			} else if (proses.equals("update")) {
				SouvenirModel souvenirModelOld = new SouvenirModel();
				souvenirModelOld = this.souvenirService.detailByID(souvenirModel.getIdSouvenir());
				
				//update created by
				souvenirModel.setCreatedBy(souvenirModelOld.getCreatedBy());
				souvenirModel.setCreatedDate(souvenirModelOld.getCreatedDate());
				souvenirModel.setIsDeleteSouvenir(souvenirModelOld.getIsDeleteSouvenir());
				
				souvenirModel.setUpdatedBy(this.getUserModel().getUsername());
				souvenirModel.setUpdatedDate(new Date());
				
				this.souvenirService.update(souvenirModel);
				
			} else if (proses.equals("delete")) {
				SouvenirModel souvenirModelOld = new SouvenirModel();
				souvenirModelOld = this.souvenirService.detailByID(souvenirModel.getIdSouvenir());
				
				souvenirModel.setCreatedBy(souvenirModelOld.getCreatedBy());
				souvenirModel.setCreatedDate(souvenirModelOld.getCreatedDate());
				
				souvenirModel.setUpdatedBy(this.getUserModel().getUsername());
				souvenirModel.setUpdatedDate(new Date());
				
				souvenirModel.setIsDeleteSouvenir(1);
				
				this.souvenirService.update(souvenirModel);
			} 
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("result",proses);
		return "souvenir";
	}
	
	@RequestMapping(value="souvenir/list")
	private String list(Model model, HttpServletRequest request) {
		
		List<SouvenirModel> souvenirs = null;
		List<UnitModel> units = new ArrayList<UnitModel>();

		try {
				souvenirs = this.souvenirService.list();
				units = this.unitService.list();
		} catch (Exception e) {
				
		}

		
		model.addAttribute("souvenirList", souvenirs);
		model.addAttribute("unitList", units);
		
		return "souvenir/list";
	}
	
	@RequestMapping(value="souvenir/detail")
	private String detail(HttpServletRequest request, Model model) {
		// TODO Auto-generated method stub
		Integer idSouvenir = Integer.valueOf(request.getParameter("idSouvenir"));
		SouvenirModel souvenirModel = new SouvenirModel();
		
		List<UnitModel> units = new ArrayList<UnitModel>();
		
		try {
			souvenirModel = this.souvenirService.detailByID(idSouvenir);
			units = this.unitService.list();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		model.addAttribute("souvenirModel", souvenirModel);
		model.addAttribute("unitList", units);
		return "souvenir/detail";
	}
	
	@RequestMapping(value="souvenir/edit")
	private String edit(HttpServletRequest request, Model model) {
	// TODO Auto-generated method stub
		Integer idSouvenir = Integer.valueOf(request.getParameter("idSouvenir"));
		SouvenirModel souvenirModel = new SouvenirModel();
		
		List<UnitModel> unitList = new ArrayList<UnitModel>();
					
		try {
				souvenirModel = this.souvenirService.detailByID(idSouvenir);
				unitList = this.unitService.list();
				
		} catch (Exception e) {
				// TODO: handle exception
		}
		
		
		model.addAttribute("souvenirModel", souvenirModel);
		model.addAttribute("unitList", unitList);
		
		return "souvenir/edit";
	}
	
	
	@RequestMapping(value="souvenir/delete")
	private String delete(HttpServletRequest request, Model model) {
	// TODO Auto-generated method stub
	Integer idSouvenir = Integer.valueOf(request.getParameter("idSouvenir"));
	SouvenirModel souvenirModel = new SouvenirModel();
	
	List<UnitModel> units = new ArrayList<UnitModel>();
							
	try {
			souvenirModel = this.souvenirService.detailByID(idSouvenir);
			units = this.unitService.list();
			
	} catch (Exception e) {
			// TODO: handle exception
	}
							
		model.addAttribute("souvenirModel", souvenirModel);
		model.addAttribute("unitList", units);
		return "souvenir/delete";
	}
}
