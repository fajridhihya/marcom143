package com.spring.marcom143.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.UnitModel;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.UnitService;
import com.spring.marcom143.tools.KodeGenerator;

@Controller
public class UnitController extends BaseController {
	
	@Autowired
	private UnitService unitService;
	@Autowired
	private MenuService menuService;
	
	
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	@RequestMapping(value="unit")
	public String index(Model model) {
		this.accessLogin(model);
		return "unit";
	}
	
	@RequestMapping(value="unit/add")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub

		String codeUnitGenerator = "";
		Boolean cek = false;
		
		while (cek == false) {
			UnitModel unitModel = new UnitModel();
			
			codeUnitGenerator = KodeGenerator.generator("UN");
			
			unitModel = this.unitService.detailByCode(codeUnitGenerator);
			
			if (unitModel == null) {
				cek = true;
			}
			
			model.addAttribute("codeUnitGenerator", codeUnitGenerator);
			
		}
		
		return "unit/add";
	}
	
	@RequestMapping(value="unit/simpan")
	private String simpan(@ModelAttribute UnitModel unitModel, HttpServletRequest request, Model model) {
		// TODO Auto-generated method stub
		
		String proses = request.getParameter("proses");
		
		try {
			
			if (proses.equals("insert")) {
				//set created
				unitModel.setCreatedBy(this.getUserModel().getUsername());
				unitModel.setCreatedDate(new Date());
				
				//set isdelete
				unitModel.setIsDeleteUnit(0);
				
				this.unitService.insert(unitModel);
				
			} else if (proses.equals("update")) {
				UnitModel unitModelOld = new UnitModel();
				unitModelOld = this.unitService.detailByID(unitModel.getIdUnit());
				
				//update created by
				unitModel.setCreatedBy(unitModelOld.getCreatedBy());
				unitModel.setCreatedDate(unitModelOld.getCreatedDate());
				unitModel.setIsDeleteUnit(unitModelOld.getIsDeleteUnit());
				
				unitModel.setUpdatedBy(this.getUserModel().getUsername());
				unitModel.setUpdatedDate(new Date());
				
				this.unitService.update(unitModel);
				
			} else if (proses.equals("delete")) {
				UnitModel unitModelOld = new UnitModel();
				unitModelOld = this.unitService.detailByID(unitModel.getIdUnit());
				
				unitModel.setCreatedBy(unitModelOld.getCreatedBy());
				unitModel.setCreatedDate(unitModelOld.getCreatedDate());
				
				unitModel.setUpdatedBy(this.getUserModel().getUsername());
				unitModel.setUpdatedDate(new Date());
				
				unitModel.setIsDeleteUnit(1);
				
				this.unitService.update(unitModel);
			} 
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("result",proses);
		return "unit";
	}
	
	@RequestMapping(value="unit/list")
	private String list(Model model) {
		
		List<UnitModel> units = null;

		try {
				
				units = this.unitService.list();
		} catch (Exception e) {
				
		}

		
		model.addAttribute("unitList", units);
		
		return "unit/list";
	}
	
	@RequestMapping(value="unit/detail")
	private String detail(HttpServletRequest request, Model model) {
		// TODO Auto-generated method stub
		Integer idUnit = Integer.valueOf(request.getParameter("idUnit"));
		UnitModel unitModel = new UnitModel();
		
		try {
			unitModel = this.unitService.detailByID(idUnit);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		model.addAttribute("unitModel", unitModel);
		return "unit/detail";
	}
	
	@RequestMapping(value="unit/edit")
	private String edit(HttpServletRequest request, Model model) {
	// TODO Auto-generated method stub
		Integer idUnit = Integer.valueOf(request.getParameter("idUnit"));
		UnitModel unitModel = new UnitModel();
		
		try {
			unitModel = this.unitService.detailByID(idUnit);
						
		} catch (Exception e) {
				// TODO: handle exception
		}
					
		
		model.addAttribute("unitModel", unitModel);
		return "unit/edit";
	}
	
	
	@RequestMapping(value="unit/delete")
	private String delete(HttpServletRequest request, Model model) {
	// TODO Auto-generated method stub
		Integer idUnit = Integer.valueOf(request.getParameter("idUnit"));
		UnitModel unitModel = new UnitModel();
		
	try {
			unitModel = this.unitService.detailByID(idUnit);
								
	} catch (Exception e) {
			// TODO: handle exception
	}
							
		model.addAttribute("unitModel", unitModel);
		return "unit/delete";
	}
}
