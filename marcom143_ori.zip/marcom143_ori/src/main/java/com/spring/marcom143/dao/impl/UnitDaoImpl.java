package com.spring.marcom143.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.marcom143.dao.UnitDao;
import com.spring.marcom143.model.UnitModel;

@Repository
public class UnitDaoImpl implements UnitDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insert(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.save(unitModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UnitModel> list() throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		List<UnitModel> result = session.createQuery("from UnitModel where isDeleteUnit = 0").list();
		return result;
	}

	@Override
	public UnitModel detailByCode(String codeUnit) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		UnitModel result = null;
		try {
			result = (UnitModel) session.createQuery("from UnitModel where codeUnit='"+codeUnit+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return result;
	}

	@Override
	public void update(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(unitModel);
	}

	@Override
	public void delete(UnitModel unitModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(unitModel);
	}

	@Override
	public UnitModel detailByID(Integer idUnit) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		UnitModel result = session.get(UnitModel.class, idUnit);
		return result;
	}

}
