package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.marcom143.model.CompanyModel;
import com.spring.marcom143.model.EmployeeModel;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.service.CompanyService;
import com.spring.marcom143.service.EmployeeService;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.tools.EmployeeCodeGenerator;

@Controller
public class EmployeeController extends BaseController{

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private MenuService menuService;

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	/*requestmapping value maksdnya ketika diklik url/ action dari employee.html */
	/*String employee(Model model) maksudnya ini adalah method employee*/
	@RequestMapping(value="employee")
	public String employee(Model model) {
		this.accessLogin(model);
		// return employee mksdnya memanggil employee.jsp di folder web-inf/jsp
		return "employee";		
	}
	
	//action url memanggil tambah company.jsp
			@RequestMapping(value="employee/tambah")
			private String tambah(Model model) throws Exception {
				// TODO Auto-generated method stub
				// Skrip untuk generate Kode otomatis
				String codeEmployeeGenerator = "";
				Boolean cek = false;

				while (cek == false) {

					EmployeeModel employeeModel = new EmployeeModel();
					// kode digenerate dengan inisial namanya, semisal SUP
					// ini kode akan dihasilkan dari kelas KodeGenerator
					codeEmployeeGenerator = EmployeeCodeGenerator.generator("");

					// setelah itu dicek dlu apakah kode hasil generatenya sudah ada di database
					employeeModel = this.employeeService.detailByCode(codeEmployeeGenerator);

					// jika benar maka looping while berhenti, dan kode terakhir generate
					// akan dijadikan kode yang ditampilkan di jspnya
					if (employeeModel == null) {
						cek = true;
					}

					// kodeemployeeGenerator akan dikirim ke pop up tambah employee jsp
					// dimana akan mengisi otomatis nilainya
					model.addAttribute("codeEmployeeGenerator", codeEmployeeGenerator);

				}
				
				
				List<CompanyModel> companys = new ArrayList<CompanyModel>();
				try {
					companys = this.companyService.list();
				} catch (Exception e) {
					// TODO: handle exception
				}
				
				model.addAttribute("companyList",companys);
				return "employee/add";
			}
	
			//action url memanggil tambah employee.jsp
			@RequestMapping(value="employee/simpan")
			private String simpan(@ModelAttribute EmployeeModel employeeModel, HttpServletRequest request, Model model) {
				// TODO Auto-generated method stub
				/*variable proses menentukan apakah kita ingin insert data baru, update data lama, atau hapus data*/
				String proses = request.getParameter("proses");
				
				/*dibutuhkan try catch karena memanggil service*/
				try {
					
					if (proses.equals("insert")) {
						// Set create and on
						employeeModel.setCreatedBy(this.getUserModel().getUsername());
						employeeModel.setCreatedDate(new Date());
						
						//Set is_delete defaultnya 0 --> artinya belum terhapus
						employeeModel.setIsDelete(0);
						
						this.employeeService.insert(employeeModel);
						
					}else if (proses.equals("update")) {
						// Set modified by and on
						EmployeeModel employeeModelOld = new EmployeeModel();
						employeeModelOld = this.employeeService.detailByID(employeeModel.getEmployee_id());
						
						employeeModel.setCreatedBy(employeeModelOld.getCreatedBy());
						employeeModel.setCreatedDate(employeeModelOld.getCreatedDate());
						employeeModel.setIsDelete(employeeModelOld.getIsDelete());
						
						employeeModel.setUpdatedBy(this.getUserModel().getUsername());
						employeeModel.setUpdatedDate(new Date());
						
						this.employeeService.update(employeeModel);
						
					}else if (proses.equals("delete")) {
						//deletenya hanya update is_delete tdnya 0 jd 1
						EmployeeModel employeeModelOld = new EmployeeModel();
						employeeModelOld = this.employeeService.detailByID(employeeModel.getEmployee_id());
						
						employeeModel.setCreatedBy(employeeModelOld.getCreatedBy());
						employeeModel.setCreatedDate(employeeModelOld.getCreatedDate());
						
						employeeModel.setUpdatedBy(this.getUserModel().getUsername());
						employeeModel.setUpdatedDate(new Date());
						
						employeeModel.setIsDelete(1);
						
						this.employeeService.update(employeeModel);
						
					}else {
						
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
				
				model.addAttribute("result",proses);
				return "employee";
			}
			
			//action untuk menampilkan looping data employee dari table employee
			@RequestMapping(value="employee/list")
			private String list(Model model) {
				// membuat object list dari class employee model
				// List nya import dari java.util
				List<EmployeeModel> employees = null;

				try {
					// object items diisi data dari method get
					employees = this.employeeService.list();
				} catch (Exception e) {
					//log.error(e.getMessage(), e);
				}

				// datanya kita kirim ke view = jsp,
				// kita buat variable list kemudian diisi dengan object employees
				model.addAttribute("employeeList", employees);
				
				//model.addAttribute(VARIABLE DI JSP, NILAI VARIABLENYA);
				
				return "employee/list";
			}
			
			//action untuk menampilkan pop up form detail
			@RequestMapping(value="employee/detail")
			private String detail(HttpServletRequest request,Model model) {
				// TODO Auto-generated method stub
				Integer employee_id = Integer.valueOf(request.getParameter("employee_id"));
				EmployeeModel employeeModel = new EmployeeModel();
				List<CompanyModel> companys = new ArrayList<CompanyModel>();
				
				try {
					
					employeeModel = this.employeeService.detailByID(employee_id);
					companys = this.companyService.list();
							
				} catch (Exception e) {
					// TODO: handle exception
				}
				
				//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
				model.addAttribute("employeeModel",employeeModel);
				model.addAttribute("companyList",companys);
				
				return "employee/detail";

			}
			
			//action untuk menampilkan pop up form detail
			@RequestMapping(value="employee/edit")
			private String edit(HttpServletRequest request,Model model) {
				// TODO Auto-generated method stub
				Integer employee_id = Integer.valueOf(request.getParameter("employee_id"));
				EmployeeModel employeeModel = new EmployeeModel();
				List<CompanyModel> companys = new ArrayList<CompanyModel>();
				
				try {
						
					employeeModel = this.employeeService.detailByID(employee_id);
					companys = this.companyService.list();
							
				} catch (Exception e) {
					// TODO: handle exception
				}
					
				//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
				model.addAttribute("employeeModel",employeeModel);
				model.addAttribute("companyList",companys);

				return "employee/edit";

			}
			
			//action untuk menampilkan pop up form delete
			@RequestMapping(value="employee/delete")
			private String delete(HttpServletRequest request,Model model) {
				// TODO Auto-generated method stub
				Integer employee_id = Integer.valueOf(request.getParameter("employee_id"));
				EmployeeModel employeeModel = new EmployeeModel();
				List<CompanyModel> companys = new ArrayList<CompanyModel>();
				
				try {
						
					employeeModel = this.employeeService.detailByID(employee_id);
					companys = this.companyService.list();
							
				} catch (Exception e) {
					// TODO: handle exception
				}
						
				//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
				model.addAttribute("employeeModel",employeeModel);
				model.addAttribute("companyList",companys);
				
				return "employee/delete";

			}
	
}
