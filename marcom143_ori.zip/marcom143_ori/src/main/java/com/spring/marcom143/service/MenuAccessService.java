package com.spring.marcom143.service;

import java.util.List;

import com.spring.marcom143.model.MenuAccessModel;

public interface MenuAccessService {
	
	public void insert(MenuAccessModel menuAccessModel) throws Exception;
	public List<MenuAccessModel> list() throws Exception;
	public MenuAccessModel detail(Integer idMenuAccess) throws Exception;
	public void update(MenuAccessModel menuAccessModel) throws Exception;
	public void delete(MenuAccessModel menuAccessModel) throws Exception;
	
	public List<MenuAccessModel> cekMenuAccess(Integer idRole, Integer idMenu) throws Exception;
	
}
