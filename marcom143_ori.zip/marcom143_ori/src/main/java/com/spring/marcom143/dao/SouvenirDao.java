package com.spring.marcom143.dao;

import java.util.List;

import com.spring.marcom143.model.SouvenirModel;

public interface SouvenirDao {
	
	public void insert(SouvenirModel souvenirModel) throws Exception;
	public List<SouvenirModel> list() throws Exception;
	public SouvenirModel detailByCode(String codeSouvenir) throws Exception;
	public SouvenirModel detailByID(Integer idSouvenir) throws Exception;
	public void update(SouvenirModel souvenirModel) throws Exception;
	public void delete(SouvenirModel souvenirModel) throws Exception;
}
