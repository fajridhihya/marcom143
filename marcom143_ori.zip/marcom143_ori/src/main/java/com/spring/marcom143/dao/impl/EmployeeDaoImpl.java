package com.spring.marcom143.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.spring.marcom143.dao.EmployeeDao;
import com.spring.marcom143.model.EmployeeModel;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insert(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		//Session importnya yg hibernate
				Session session = this.sessionFactory.getCurrentSession();
				
				/*skrip queri insert into tp dalam bentuk hibernate*/
				session.save(employeeModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmployeeModel> list() throws Exception {
		// TODO Auto-generated method stub
		// sessionFactory.getCurrentSession() fungsi utk inisiasi skrip querinya dgn
		// fungsi hibernate
		Session session = this.sessionFactory.getCurrentSession();

		/* session.createQuery adalah skrip queri dari select * from M_EMPLOYEE */
		List<EmployeeModel> result = session.createQuery("from EmployeeModel where isDelete = 0").list();
		return result;
	}

	@Override
	public void update(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.delete adalah skrip query dari delete from M_EMPLOYEE where
		 * primaryKey = nilaiPrimaryKey
		 */
		session.update(employeeModel);
	}

	@Override
	public void delete(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.delete adalah skrip query dari delete from M_EMPLOYEE where
		 * primaryKey = nilaiPrimaryKey
		 */
		session.delete(employeeModel);
	}

	@Override
	public EmployeeModel detailByCode(String employee_number) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeModel result = null;
		try {
			result = (EmployeeModel) session.createQuery("from EmployeeModel where employee_number='"+employee_number+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return result;
	}

	@Override
	public EmployeeModel detailByID(Integer employee_id) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		EmployeeModel result = session.get(EmployeeModel.class, employee_id);
		return result;
	}
	
	
	
}
