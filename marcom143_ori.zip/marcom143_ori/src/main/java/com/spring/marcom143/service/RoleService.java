package com.spring.marcom143.service;
import java.util.List;

import com.spring.marcom143.model.RoleModel;
public interface RoleService {
	
	public void insert(RoleModel roleModel) throws Exception;
	//ini adalah service list
	public List<RoleModel>list() throws Exception;
	public RoleModel detailByCode(String codeRole) throws Exception;
	public RoleModel detailById(Integer idRole) throws Exception;
	public void update(RoleModel roleModel) throws Exception;
	public void delete(RoleModel roleModel) throws Exception;
}