package com.spring.marcom143.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.marcom143.model.EmployeeModel;
import com.spring.marcom143.model.MenuModel;
import com.spring.marcom143.model.TSouvenirModel;
import com.spring.marcom143.service.EmployeeService;
import com.spring.marcom143.service.MenuService;
import com.spring.marcom143.service.TSouvenirService;
import com.spring.marcom143.tools.KodeGenerator;

@Controller
public class TSouvenirController extends BaseController{

	@Autowired
	private TSouvenirService tsouvenirService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private MenuService menuService;

	// method untuk menampilkan menu by role login dan user login
	// perlu ditambahkan extend BaseController serta autowired menuService
	public void accessLogin(Model model) {

		model.addAttribute("username", this.getUserModel().getUsername());
		model.addAttribute("rolename", this.getUserModel().getRoleModel().getNameRole());

		// logic untuk list menu secara hirarki by role
		List<MenuModel> menuList = null;
		try {
			// menuList = this.menuService.getAllMenuTree(">");
			menuList = this.menuService.getMenuLogin(this.getUserModel().getRoleModel().getIdRole());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("menuList", menuList);
	}
	// akhir method untuk menampilkan menu by role login dan user login
	
	/*requestmapping value maksdnya ketika diklik url/ action dari tsouvenir.html */
	/*String tsouvenir(Model model) maksudnya ini adalah method tsouvenir*/
	@RequestMapping(value="tsouvenir")
	public String tsouvenir(Model model) {
		this.accessLogin(model);
		// return tsouvenir mksdnya memanggil tsouvenir.jsp di folder web-inf/jsp
		return "tsouvenir";		
	}
	
	//action url memanggil tambah tsouvenir.jsp
	@RequestMapping(value = "tsouvenir/tambah")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub
		// Skrip untuk generate Kode otomatis
		String codetsouvenirGenerator = "";
		Boolean cek = false;

		while (cek == false) {

			TSouvenirModel tsouvenirModel = new TSouvenirModel();
			// kode digenerate dengan inisial namanya, semisal SUP
			// ini kode akan dihasilkan dari kelas KodeGenerator
			codetsouvenirGenerator = KodeGenerator.generator("TRSV");

			// setelah itu dicek dlu apakah kode hasil generatenya sudah ada di database
			tsouvenirModel = this.tsouvenirService.detailByCode(codetsouvenirGenerator);

			// jika benar maka looping while berhenti, dan kode terakhir generate
			// akan dijadikan kode yang ditampilkan di jspnya
			if (tsouvenirModel == null) {
				cek = true;
			}

			// kodetsouvenirGenerator akan dikirim ke pop up tambah tsouvenir jsp
			// dimana akan mengisi otomatis nilainya
			model.addAttribute("codetsouvenirGenerator", codetsouvenirGenerator);

		}
		
		List<EmployeeModel> employees = new ArrayList<EmployeeModel>();
		try {
			employees = this.employeeService.list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		model.addAttribute("employeeList",employees);
		return "tsouvenir/add";
	}
		
		//action url memanggil tambah tsouvenir.jsp
		@RequestMapping(value="tsouvenir/simpan")
		private String simpan(@ModelAttribute TSouvenirModel tsouvenirModel, HttpServletRequest request, Model model) {
			// TODO Auto-generated method stub
			/*variable proses menentukan apakah kita ingin insert data baru, update data lama, atau hapus data*/
			String proses = request.getParameter("proses");
			
			/*dibutuhkan try catch karena memanggil service*/
			try {
				
				if (proses.equals("insert")) {
					// Set create and on
					tsouvenirModel.setCreatedBy(this.getUserModel().getUsername());
					tsouvenirModel.setCreatedDate(new Date());
					
					//Set is_delete defaultnya 0 --> artinya belum terhapus
					tsouvenirModel.setIsDelete(0);
					
					this.tsouvenirService.insert(tsouvenirModel);
					
				}else if (proses.equals("update")) {
					// Set modified by and on
					TSouvenirModel tsouvenirModelOld = new TSouvenirModel();
					tsouvenirModelOld = this.tsouvenirService.detailByID(tsouvenirModel.getTsouvenir_id());
					
					tsouvenirModel.setCreatedBy(tsouvenirModelOld.getCreatedBy());
					tsouvenirModel.setCreatedDate(tsouvenirModelOld.getCreatedDate());
					tsouvenirModel.setIsDelete(tsouvenirModelOld.getIsDelete());
					
					tsouvenirModel.setUpdatedBy(this.getUserModel().getUsername());
					tsouvenirModel.setUpdatedDate(new Date());
					
					this.tsouvenirService.update(tsouvenirModel);
					
				}else if (proses.equals("delete")) {
					//deletenya hanya update is_delete tdnya 0 jd 1
					TSouvenirModel tsouvenirModelOld = new TSouvenirModel();
					tsouvenirModelOld = this.tsouvenirService.detailByID(tsouvenirModel.getTsouvenir_id());
					
					tsouvenirModel.setCreatedBy(tsouvenirModelOld.getCreatedBy());
					tsouvenirModel.setCreatedDate(tsouvenirModelOld.getCreatedDate());
					
					tsouvenirModel.setUpdatedBy(this.getUserModel().getUsername());
					tsouvenirModel.setUpdatedDate(new Date());
					
					tsouvenirModel.setIsDelete(1);
					
					this.tsouvenirService.delete(tsouvenirModel);
					
				}else {
					
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			model.addAttribute("result",proses);
			return "tsouvenir";
		}
	
		//action untuk menampilkan looping data tsouvenir dari table tsouvenir
		@RequestMapping(value="tsouvenir/list")
		private String list(Model model) {
			// membuat object list dari class tsouvenir model
			// List nya import dari java.util
			List<TSouvenirModel> tsouvenirs = null;

			try {
				// object items diisi data dari method get
				tsouvenirs = this.tsouvenirService.list();
			} catch (Exception e) {
				//log.error(e.getMessage(), e);
			}

			// datanya kita kirim ke view = jsp,
			// kita buat variable list kemudian diisi dengan object tsouvenirs
			model.addAttribute("tsouvenirList", tsouvenirs);
			
			//model.addAttribute(VARIABLE DI JSP, NILAI VARIABLENYA);
			
			return "tsouvenir/list";
		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="tsouvenir/detail")
		private String detail(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer tsouvenir_id = Integer.valueOf(request.getParameter("tsouvenir_id"));
			TSouvenirModel tsouvenirModel = new TSouvenirModel();
			List<EmployeeModel> employees = new ArrayList<EmployeeModel>();
			
			try {
				
				tsouvenirModel = this.tsouvenirService.detailByID(tsouvenir_id);
				employees = this.employeeService.list();
						
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("tsouvenirModel",tsouvenirModel);
			model.addAttribute("employeeList",employees);
			return "tsouvenir/detail";

		}
		
		//action untuk menampilkan pop up form detail
		@RequestMapping(value="tsouvenir/edit")
		private String edit(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer tsouvenir_id = Integer.valueOf(request.getParameter("tsouvenir_id"));
			TSouvenirModel tsouvenirModel = new TSouvenirModel();
			List<EmployeeModel> employees = new ArrayList<EmployeeModel>();
			
			try {
					
				tsouvenirModel = this.tsouvenirService.detailByID(tsouvenir_id);
				employees = this.employeeService.list();
						
			} catch (Exception e) {
				// TODO: handle exception
			}
				
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("tsouvenirModel",tsouvenirModel);
			model.addAttribute("employeeList",employees);
			return "tsouvenir/edit";

		}
		
		//action untuk menampilkan pop up form delete
		@RequestMapping(value="tsouvenir/delete")
		private String delete(HttpServletRequest request,Model model) {
			// TODO Auto-generated method stub
			Integer tsouvenir_id = Integer.valueOf(request.getParameter("tsouvenir_id"));
			TSouvenirModel tsouvenirModel = new TSouvenirModel();
			List<EmployeeModel> employees = new ArrayList<EmployeeModel>();
			
			try {
					
				tsouvenirModel = this.tsouvenirService.detailByID(tsouvenir_id);
				employees = this.employeeService.list();
						
			} catch (Exception e) {
				// TODO: handle exception
			}
					
			//modelAddAttribute fungsinya untuk kirim nilai dari controller ke jsp
			model.addAttribute("tsouvenirModel",tsouvenirModel);
			model.addAttribute("employeeList",employees);
			return "tsouvenir/delete";

		}
	
}
