package com.spring.marcom143.service;
import java.util.List;
import com.spring.marcom143.model.EmployeeModel;

public interface EmployeeService {
	public void insert(EmployeeModel employeeModel) throws Exception;
	public List<EmployeeModel> list() throws Exception;

	public EmployeeModel detailByCode(String employee_number) throws Exception;
	public EmployeeModel detailByID(Integer employee_id) throws Exception;
	
	public void update(EmployeeModel employeeModel) throws Exception;
	public void delete(EmployeeModel employeeModel) throws Exception;
}
