package com.spring.marcom143.service.impl;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.marcom143.dao.TSouvenirItemDao;
import com.spring.marcom143.model.TSouvenirItemModel;
import com.spring.marcom143.service.TSouvenirItemService;

@Service
@Transactional
public class TSouvenirItemServiceImpl implements TSouvenirItemService {

	@Autowired
	private TSouvenirItemDao tSouvenirItemDao;
	
	@Override
	public void insert(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirItemDao.insert(tsouveniritemModel);
	}

	@Override
	public List<TSouvenirItemModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.tSouvenirItemDao.list();
	}

	@Override
	public void update(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirItemDao.update(tsouveniritemModel);
	}

	@Override
	public void delete(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirItemDao.delete(tsouveniritemModel);
	}

	@Override
	public TSouvenirItemModel detailByID(Integer tsouvenir_id_item) throws Exception {
		// TODO Auto-generated method stub
		return this.tSouvenirItemDao.detailByID(tsouvenir_id_item);
	}
	
	

}
