package com.spring.marcom143.service.impl;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.marcom143.dao.TSouvenirDao;
import com.spring.marcom143.model.TSouvenirModel;
import com.spring.marcom143.service.TSouvenirService;

@Service
@Transactional
public class TSouvenirServiceImpl implements TSouvenirService {

	@Autowired
	private TSouvenirDao tSouvenirDao;
	
	@Override
	public void insert(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirDao.insert(tsouvenirModel);
	}

	@Override
	public List<TSouvenirModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.tSouvenirDao.list();
	}

	@Override
	public void update(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirDao.update(tsouvenirModel);
	}

	@Override
	public void delete(TSouvenirModel tsouvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.tSouvenirDao.delete(tsouvenirModel);
	}

	@Override
	public TSouvenirModel detailByCode(String tsouvenir_code) throws Exception {
		// TODO Auto-generated method stub
		return this.tSouvenirDao.detailByCode(tsouvenir_code);
	}

	@Override
	public TSouvenirModel detailByID(Integer tsouvenir_id) throws Exception {
		// TODO Auto-generated method stub
		return this.tSouvenirDao.detailByID(tsouvenir_id);
	}
	
	

}
