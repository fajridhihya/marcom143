package com.spring.marcom143.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.marcom143.dao.MenuAccessDao;
import com.spring.marcom143.model.MenuAccessModel;
import com.spring.marcom143.service.MenuAccessService;

@Service
@Transactional
public class MenuAccessServiceImpl implements MenuAccessService{

	@Autowired
	private MenuAccessDao MenuAccessDao;
	
	@Override
	public void insert(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		this.MenuAccessDao.insert(menuAccessModel);
	}

	@Override
	public List<MenuAccessModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.MenuAccessDao.list();
	}

	@Override
	public MenuAccessModel detail(Integer idMenuAccess) throws Exception {
		// TODO Auto-generated method stub
		return this.MenuAccessDao.detail(idMenuAccess);
	}

	@Override
	public void update(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		this.MenuAccessDao.update(menuAccessModel);
	}

	@Override
	public void delete(MenuAccessModel menuAccessModel) throws Exception {
		// TODO Auto-generated method stub
		this.MenuAccessDao.delete(menuAccessModel);
	}

	@Override
	public List<MenuAccessModel> cekMenuAccess(Integer idRole, Integer idMenu) throws Exception {
		// TODO Auto-generated method stub
		return this.MenuAccessDao.cekMenuAccess(idRole, idMenu);
	}

}
