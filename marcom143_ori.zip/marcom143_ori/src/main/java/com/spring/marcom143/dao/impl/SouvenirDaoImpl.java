package com.spring.marcom143.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.marcom143.dao.SouvenirDao;
import com.spring.marcom143.model.SouvenirModel;

@Repository
public class SouvenirDaoImpl implements SouvenirDao{

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void insert(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.save(souvenirModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SouvenirModel> list() throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		List<SouvenirModel> result = session.createQuery("from SouvenirModel where isDeleteSouvenir = 0").list();
		return result;
	}

	@Override
	public SouvenirModel detailByCode(String codeSouvenir) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		SouvenirModel result = null;
		
		try {
			result = (SouvenirModel) session.createQuery("from SouvenirModel where codeSouvenir='"+codeSouvenir+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		return result;
	}

	@Override
	public void update(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(souvenirModel);
	}

	@Override
	public void delete(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(souvenirModel);
	}

	@Override
	public SouvenirModel detailByID(Integer idSouvenir) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		SouvenirModel result = session.get(SouvenirModel.class, idSouvenir);
		return result;
	}

	
}
