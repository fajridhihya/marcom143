package com.spring.marcom143.service.impl;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.marcom143.dao.RoleDao;
import com.spring.marcom143.model.RoleModel;
import com.spring.marcom143.service.RoleService;



@Service
@Transactional
public class RoleServiceImpl implements RoleService{
	@Autowired
	private RoleDao roleDao;

	@Override
	public void insert(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		this.roleDao.insert(roleModel);
		
	}

	@Override
	public List<RoleModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.roleDao.list();
	}

	

	@Override
	public void update(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		this.roleDao.update(roleModel);
	}

	@Override
	public void delete(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		this.roleDao.delete(roleModel);
		
	}

	@Override
	public RoleModel detailByCode(String codeRole) throws Exception {
		// TODO Auto-generated method stub
		return this.roleDao.detailByCode(codeRole);
	}

	@Override
	public RoleModel detailById(Integer idRole) throws Exception {
		// TODO Auto-generated method stub
		return this.roleDao.detailById(idRole);
	}

	
	
}
