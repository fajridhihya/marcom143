package com.spring.marcom143.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.marcom143.dao.RoleDao;
import com.spring.marcom143.model.RoleModel;


@Repository
public class RoleDaoImpl implements RoleDao{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void insert(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.save(roleModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RoleModel> list() throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		List<RoleModel> result = session.createQuery("from RoleModel where isDeleteRole = 0 ").list();
		return result;

	}

	

	@Override
	public void update(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.update(roleModel);
	}

	@Override
	public void delete(RoleModel roleModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.delete(roleModel);
		
	}

	@Override
	public RoleModel detailByCode(String codeRole) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		RoleModel result = null;
		try {
			result = (RoleModel) session.createQuery("from RoleModel where codeRole = '"+codeRole+"'").getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return result;
	}

	@Override
	public RoleModel detailById(Integer idRole) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		RoleModel result = session.get(RoleModel.class, idRole);
		return result;
	}

	
}
