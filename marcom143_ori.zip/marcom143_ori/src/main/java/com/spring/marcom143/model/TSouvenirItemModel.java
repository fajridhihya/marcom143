package com.spring.marcom143.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="T_SOUVENIR_ITEM")
public class TSouvenirItemModel {
	
	private Integer tsouvenir_id_item;
	
	private Integer tsouvenir_id;
	private TSouvenirModel tsouvenirModel;
	
	private Integer idSouvenir;
	private SouvenirModel souvenirModel;
	
	private Integer tsouveniritem_qty;
	private String tsouveniritem_note;
	
	private Integer isDelete;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	
	@Id
	@Column(name="TSOUVENIR_ID_ITEM")
	@GeneratedValue(strategy=GenerationType.TABLE, generator="T_SOUVENIR_ITEM") //karena oracle ga bisa ake increment kyk sql
	@TableGenerator(name="T_SOUVENIR_ITEM", table="MST_SEQUENCE", pkColumnName="SEQUENCE_NAME",
			pkColumnValue="T_SOUVENIR_ITEM", valueColumnName="SEQUENCE_VALUE",
			allocationSize=1, initialValue=1)
	public Integer getTsouvenir_id_item() {
		return tsouvenir_id_item;
	}
	public void setTsouvenir_id_item(Integer tsouvenir_id_item) {
		this.tsouvenir_id_item = tsouvenir_id_item;
	}
	@Column(name="TSOUVENIR_ID")
	public Integer getTsouvenir_id() {
		return tsouvenir_id;
	}
	public void setTsouvenir_id(Integer tsouvenir_id) {
		this.tsouvenir_id = tsouvenir_id;
	}
	@ManyToOne
	@JoinColumn(name="TSOUVENIR_ID", nullable = false, updatable = false, insertable = false)
	public TSouvenirModel getTsouvenirModel() {
		return tsouvenirModel;
	}
	public void setTsouvenirModel(TSouvenirModel tsouvenirModel) {
		this.tsouvenirModel = tsouvenirModel;
	}
	@Column(name="ID_SOUVENIR")
	public Integer getIdSouvenir() {
		return idSouvenir;
	}
	public void setIdSouvenir(Integer idSouvenir) {
		this.idSouvenir = idSouvenir;
	}
	@ManyToOne
	@JoinColumn(name="ID_SOUVENIR", nullable = false, updatable = false, insertable = false)
	public SouvenirModel getSouvenirModel() {
		return souvenirModel;
	}
	public void setSouvenirModel(SouvenirModel souvenirModel) {
		this.souvenirModel = souvenirModel;
	}
	@Column(name="SOUVENIR_ITEM_QTY")
	public Integer getTsouveniritem_qty() {
		return tsouveniritem_qty;
	}
	public void setTsouveniritem_qty(Integer tsouveniritem_qty) {
		this.tsouveniritem_qty = tsouveniritem_qty;
	}
	@Column(name="SOUVENIR_ITEM_NOTE")
	public String getTsouveniritem_note() {
		return tsouveniritem_note;
	}
	public void setTsouveniritem_note(String tsouveniritem_note) {
		this.tsouveniritem_note = tsouveniritem_note;
	}
	@Column(name = "IS_DELETE")
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
	@Column(name = "CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name = "CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	@Column(name = "UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}
