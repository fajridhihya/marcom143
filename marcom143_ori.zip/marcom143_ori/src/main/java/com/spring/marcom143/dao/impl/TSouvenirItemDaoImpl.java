package com.spring.marcom143.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.spring.marcom143.dao.TSouvenirItemDao;
import com.spring.marcom143.model.TSouvenirItemModel;

/*repository berfungsi untuk konek ke tablenya*/
@Repository
public class TSouvenirItemDaoImpl implements TSouvenirItemDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void insert(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		//Session importnya yg hibernate
				Session session = this.sessionFactory.getCurrentSession();
				
				/*skrip queri insert into tp dalam bentuk hibernate*/
				session.save(tsouveniritemModel);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TSouvenirItemModel> list() throws Exception {
		// TODO Auto-generated method stub
		//sessionFactory.getCurrentSession() fungsi utk inisiasi skrip querinya dgn fungsi hibernate
		Session session = this.sessionFactory.getCurrentSession();

		/* session.createQuery adalah skrip queri dari select * from T_SOUVENIR */
		List<TSouvenirItemModel> result = session.createQuery("from TSouvenirItemModel").list();
		return result;
	}

	@Override
	public void update(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.update adalah skrip queri dari update T_SOUVENIR set kolom1=nilai1,
		 * kolom2=nilai2 where primaryKey=nilaiPrimaryKey
		 */
		session.update(tsouveniritemModel);
	}

	@Override
	public void delete(TSouvenirItemModel tsouveniritemModel) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();

		/*
		 * session.update adalah skrip queri dari update T_SOUVENIR set kolom1=nilai1,
		 * kolom2=nilai2 where primaryKey=nilaiPrimaryKey
		 */
		session.delete(tsouveniritemModel);
	}

	
	@Override
	public TSouvenirItemModel detailByID(Integer tsouvenir_id_item) throws Exception {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		TSouvenirItemModel result = session.get(TSouvenirItemModel.class, tsouvenir_id_item);
		return result;
	}
	
	

}
