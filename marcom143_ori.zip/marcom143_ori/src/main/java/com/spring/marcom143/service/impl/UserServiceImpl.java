package com.spring.marcom143.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.marcom143.dao.UserDao;
import com.spring.marcom143.model.UserModel;
import com.spring.marcom143.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDao;
	
	@Override
	public void insert(UserModel userModel) throws Exception {
		// TODO Auto-generated method stub
		this.userDao.insert(userModel);
	}

	@Override
	public List<UserModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.userDao.list();
	}

	@Override
	public UserModel detail(Integer idUser) throws Exception {
		// TODO Auto-generated method stub
		return this.userDao.detail(idUser);
	}

	@Override
	public void update(UserModel userModel) throws Exception {
		// TODO Auto-generated method stub
		this.userDao.update(userModel);
	}

	@Override
	public void delete(UserModel userModel) throws Exception {
		// TODO Auto-generated method stub
		this.userDao.delete(userModel);
	}

	@Override
	public UserModel getByUsernamePassword(String username, String password) throws Exception {
		// TODO Auto-generated method stub
		return this.userDao.getByUsernamePassword(username, password);
	}

}
