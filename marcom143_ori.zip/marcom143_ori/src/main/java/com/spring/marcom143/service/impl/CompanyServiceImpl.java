package com.spring.marcom143.service.impl;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.marcom143.dao.CompanyDao;
import com.spring.marcom143.model.CompanyModel;
import com.spring.marcom143.service.CompanyService;

@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;
	
	@Override
	public void insert(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		this.companyDao.insert(companyModel);
	}

	@Override
	public List<CompanyModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.companyDao.list();
	}

	@Override
	public void update(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		this.companyDao.update(companyModel);
	}

	@Override
	public void delete(CompanyModel companyModel) throws Exception {
		// TODO Auto-generated method stub
		this.companyDao.delete(companyModel);
	}

	@Override
	public CompanyModel detailByCode(String company_code) throws Exception {
		// TODO Auto-generated method stub
		return this.companyDao.detailByCode(company_code);
	}

	@Override
	public CompanyModel detailByID(Integer company_id) throws Exception {
		// TODO Auto-generated method stub
		return this.companyDao.detailByID(company_id);
	}

//	@Override
//	public int getIdMax() {
//		// TODO Auto-generated method stub
//		return this.companyDao.getIdMax();
//	}
//	
	

}
