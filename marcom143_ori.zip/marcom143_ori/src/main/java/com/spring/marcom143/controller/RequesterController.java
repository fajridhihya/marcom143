package com.spring.marcom143.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RequesterController {
	
	@RequestMapping(value="requester")
	public String index(Model model) {
		return "requester";
	}
	
	@RequestMapping(value="requester/add")
	private String tambah(Model model) throws Exception {
		// TODO Auto-generated method stub

		return "requester/add";
	}
}
