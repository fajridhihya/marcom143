package com.spring.marcom143.service.impl;
import java.util.List;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.marcom143.dao.EmployeeDao;
import com.spring.marcom143.model.EmployeeModel;
import com.spring.marcom143.service.EmployeeService;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;
	
	@Override
	public void insert(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		this.employeeDao.insert(employeeModel);
	}

	@Override
	public List<EmployeeModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.employeeDao.list();
	}

	@Override
	public void update(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		this.employeeDao.update(employeeModel);
	}

	@Override
	public void delete(EmployeeModel employeeModel) throws Exception {
		// TODO Auto-generated method stub
		this.employeeDao.delete(employeeModel);
	}

	@Override
	public EmployeeModel detailByCode(String employee_number) throws Exception {
		// TODO Auto-generated method stub
		return this.employeeDao.detailByCode(employee_number);
	}

	@Override
	public EmployeeModel detailByID(Integer employee_id) throws Exception {
		// TODO Auto-generated method stub
		return this.employeeDao.detailByID(employee_id);
	}
	
	

}
