package com.spring.marcom143.service;

import java.util.List;
import com.spring.marcom143.model.TSouvenirItemModel;

public interface TSouvenirItemService {
	public void insert(TSouvenirItemModel tsouveniritemModel) throws Exception;
	public List<TSouvenirItemModel> list() throws Exception;
	
	public TSouvenirItemModel detailByID(Integer tsouvenir_id_item) throws Exception;
	
	public void update(TSouvenirItemModel tsouveniritemModel) throws Exception;
	public void delete(TSouvenirItemModel tsouveniritemModel) throws Exception;
}
