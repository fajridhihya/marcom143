package com.spring.marcom143.dao;

import java.util.List;

import com.spring.marcom143.model.UnitModel;

public interface UnitDao {
	
	public void insert(UnitModel unitModel) throws Exception;
	public List<UnitModel> list() throws Exception;
	public UnitModel detailByCode(String codeUnit) throws Exception;
	public UnitModel detailByID(Integer idUnit) throws Exception;
	public void update(UnitModel unitModel) throws Exception;
	public void delete(UnitModel unitModel) throws Exception;
}
