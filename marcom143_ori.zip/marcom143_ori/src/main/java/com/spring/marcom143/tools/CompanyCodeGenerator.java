package com.spring.marcom143.tools;

import java.util.UUID;

public class CompanyCodeGenerator {
	public static String generator(String jenisKode) {
		String uuid = UUID.randomUUID().toString();
		String[] a = uuid.split("-");
		int count = a.length;
		String kode = jenisKode+a[count-3];
		return kode;
	}
}
