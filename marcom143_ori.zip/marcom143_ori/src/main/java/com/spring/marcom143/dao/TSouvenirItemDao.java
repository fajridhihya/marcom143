package com.spring.marcom143.dao;
import java.util.List;

import com.spring.marcom143.model.TSouvenirItemModel;

public interface TSouvenirItemDao {
	public void insert(TSouvenirItemModel tsouveniritemModel) throws Exception;
	public List<TSouvenirItemModel> list() throws Exception;
	
	public TSouvenirItemModel detailByID(Integer tsouvenir_id_item) throws Exception;
	
	public void update(TSouvenirItemModel tsouveniritemModel) throws Exception;
	public void delete(TSouvenirItemModel tsouveniritemModel) throws Exception;
}
