package com.spring.marcom143.service;
import java.util.List;
import com.spring.marcom143.model.MenuModel;
public interface MenuService {
	
	public void insert(MenuModel menuModel) throws Exception;
	//ini adalah service list
	public List<MenuModel>list() throws Exception;
	public MenuModel detailByCode(String codeMenu) throws Exception;
	public MenuModel detailById(Integer idMenu) throws Exception;
	public void update(MenuModel menuModel) throws Exception;
	public void delete(MenuModel menuModel) throws Exception;
	
	//service utk tampilin hirarki menu
	public List<MenuModel> getMenuLogin(Integer idRole) throws Exception;

}
