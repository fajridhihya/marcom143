package com.spring.marcom143.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.marcom143.dao.SouvenirDao;
import com.spring.marcom143.model.SouvenirModel;
import com.spring.marcom143.service.SouvenirService;

@Service
@Transactional
public class SouvenirServiceImpl implements SouvenirService {
	@Autowired
	private SouvenirDao souvenirDao;

	@Override
	public void insert(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.souvenirDao.insert(souvenirModel);
	}

	@Override
	public List<SouvenirModel> list() throws Exception {
		// TODO Auto-generated method stub
		return this.souvenirDao.list();
	}

	@Override
	public SouvenirModel detailByCode(String codeSouvenir) throws Exception {
		// TODO Auto-generated method stub
		return this.souvenirDao.detailByCode(codeSouvenir);
	}

	@Override
	public void update(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.souvenirDao.update(souvenirModel);
	}

	@Override
	public void delete(SouvenirModel souvenirModel) throws Exception {
		// TODO Auto-generated method stub
		this.souvenirDao.delete(souvenirModel);
	}

	@Override
	public SouvenirModel detailByID(Integer idSouvenir) throws Exception {
		// TODO Auto-generated method stub
		return this.souvenirDao.detailByID(idSouvenir);
	}

	
}
