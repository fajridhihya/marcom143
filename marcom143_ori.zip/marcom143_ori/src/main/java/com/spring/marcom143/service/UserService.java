package com.spring.marcom143.service;

import java.util.List;

import com.spring.marcom143.model.UserModel;

public interface UserService {

	public void insert(UserModel userModel) throws Exception;
	public List<UserModel> list() throws Exception;
	public UserModel detail(Integer idUser) throws Exception;
	public void update(UserModel userModel) throws Exception;
	public void delete(UserModel userModel) throws Exception;
	
	public UserModel getByUsernamePassword(String username, String password) throws Exception;
	
}
