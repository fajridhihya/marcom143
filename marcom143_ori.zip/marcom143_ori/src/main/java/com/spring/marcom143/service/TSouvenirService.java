package com.spring.marcom143.service;

import java.util.List;
import com.spring.marcom143.model.TSouvenirModel;

public interface TSouvenirService {
	public void insert(TSouvenirModel tsouvenirModel) throws Exception;
	public List<TSouvenirModel> list() throws Exception;
	
	public TSouvenirModel detailByCode(String tsouvenir_code) throws Exception;
	public TSouvenirModel detailByID(Integer tsouvenir_id) throws Exception;
	
	public void update(TSouvenirModel tsouvenirModel) throws Exception;
	public void delete(TSouvenirModel tsouvenirModel) throws Exception;
}
